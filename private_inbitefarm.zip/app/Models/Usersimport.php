<?php

namespace App\Models;

use CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Model;

class Usersimport extends Model
{
    protected $table = 'users_import';
    protected $allowedFields = [
        'nama',
        'email',
        'hp',
        'jk',
        'tanggal_lahir',
        'alamat',
        'nik'
    ];
}
