<?php

namespace App\Controllers;

use function PHPUnit\Framework\fileExists;

class Admin_web extends BaseController
{
    public function __construct()
    {
        //(me()) ?: go();
    }
    private function dir()
    {
        return 'admin_web/';
    }
    public function index()
    {
        go();
    }
    //========== admin_web/main START ===========
    public function main()
    {
        ck_uri();
        if (req()->getPost('web_home_text_color') != null) {
            $web_home_text_color = req()->getPost('web_home_text_color');
            $web_home_judul = req()->getPost('web_home_judul');
            $web_home_desk = req()->getPost('web_home_desk');
            update('temp_inc', ['code' => $web_home_text_color], ['id' => 'web_home_text_color']);
            update('temp_inc', ['code' => $web_home_judul], ['id' => 'web_home_judul']);
            update('temp_inc', ['code' => $web_home_desk], ['id' => 'web_home_desk ']);
            session()->setFlashdata('info', 'Data Berhasil Di Update');
        }
        $this->part_in($this->dir() . 'main', '', 'Setting main');
    }
    //=========== admin_web/main END ============
    //========== admin_web/tentang START ===========
    public function tentang()
    {
        ck_uri();
        if (req()->getPost('web_home_tentang_judul') != null) {
            $web_home_tentang_judul = req()->getPost('web_home_tentang_judul');
            $web_home_tentang_desk = req()->getPost('web_home_tentang_desk');
            update('temp_inc', ['code' => $web_home_tentang_judul], ['id' => 'web_home_tentang_judul']);
            update('temp_inc', ['code' => $web_home_tentang_desk], ['id' => 'web_home_tentang_desk']);
            session()->setFlashdata('info', 'Data Berhasil Di Update');
        }
        $this->part_in($this->dir() . 'tentang', '', 'Setting tentang');
    }
    //=========== admin_web/tentang END ============
    //========== admin_web/gallery START ===========
    public function gallery()
    {
        ck_uri();
        $this->part_in($this->dir() . 'gallery', '', 'Setting gallery');
    }
    public function save_gallery()
    {
        ck_uri('admin_web/gallery');
        $id = $_REQUEST['id'];

        if ($id == 'insert') {
            if ($_FILES['file']['name'] != '') {
                $test = explode('.', $_FILES['file']['name']);
                $extension = end($test);
                $name = 'gallery_' . time() . '.' . $extension;
                $location = 'img/web/gallery/' . $name;
                $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
                if ($res) {
                    $data_in['img'] = $name;
                }
            } else {
                echo json_encode(['errorMsg' => 'Tidak Ada File Terdeteksi']);
                exit;
            }
            update('web_gallery', ['sync' => ''], ['sync' => 'active']);
            $data_in['at_create'] = date("d-m-Y");
            $data_in['sync'] = 'active';
            insert('web_gallery', $data_in);
        } else {
            $o = db('web_gallery')->getWhere(['id' => $id], 1)->getRow();
            if ($_FILES['file']['name'] != '') {
                $test = explode('.', $_FILES['file']['name']);
                $extension = end($test);
                $name = 'gallery_' . time() . '.' . $extension;
                $location = 'img/web/gallery/' . $name;
                $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
                if ($res) {
                    $data_in['img'] = $name;
                }
                if ($o->img != null) {
                    $path = FCPATH . 'img/web/gallery/' . $o->img;
                    (!file_exists($path)) ?: unlink($path);
                }
            }
            update('web_gallery', $data_in, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_gallery()
    {
        ck_uri('admin_web/gallery');
        $id = $_REQUEST['id'];
        $o = db('web_gallery')->getWhere(['id' => $id], 1)->getRow();
        if ($o->img != null) {
            $path = FCPATH . 'img/web/gallery/' . $o->img;
            (!file_exists($path)) ?: unlink($path);
        }
        delete('web_gallery', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_gallery()
    {
        ck_uri('admin_web/gallery');
        $id = $_REQUEST['id'];
        $o = db('web_gallery')->getWhere(['id' => $id], 1)->getRow();
        if ($o->sync == 'active') {
            $x = db('web_gallery')->getWhere(['sync' => ''], 1)->getRow();
            update('web_gallery', ['sync' => 'active'], ['id' => $x->id]);
            update('web_gallery', ['sync' => ''], ['id' => $id]);
        }
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('web_gallery', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_gallery()
    {
        ck_uri('admin_web/gallery');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('web_gallery');
        $country = db('web_gallery')
            ->orderBy('id', 'DESC')
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    //=========== admin_web/gallery END ============
    /** =====================================================================
     * admin_web/contact START
     *=====================================================================*/
    public function contact()
    {
        ck_uri();
        $this->part_in($this->dir() . 'contact', '', 'Setting contact');
    }
    public function save_contact()
    {
        ck_uri('admin_web/contact');
        $id = $_REQUEST['id'];
        $label = $_REQUEST['label'];
        $url = $_REQUEST['url'];
        $data = [
            'label' => $label,
            'url' => $url,
        ];
        if ($id == 'insert') {
            insert('web_contact', $data);
        } else {
            update('web_contact', $data, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_contact()
    {
        ck_uri('admin_web/contact');
        $id = $_REQUEST['id'];
        delete('web_contact', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_contact()
    {
        ck_uri('admin_web/contact');
        $id = $_REQUEST['id'];
        $o = db('web_contact')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('web_contact', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_contact()
    {
        ck_uri('admin_web/contact');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'web_contact.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('web_contact');
        $country = db('web_contact')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->like('label', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * admin_web/contact END
     *=====================================================================*/
    /** =====================================================================
     * admin_web/other START
     *=====================================================================*/
    public function other()
    {
        ck_uri();
        $this->part_in($this->dir() . 'other', '', 'Setting other');
    }
    public function save_other()
    {
        ck_uri('admin_web/other');
        $id = $_REQUEST['id'];
        $label = $_REQUEST['label'];
        $content = $_REQUEST['content'];
        $data = [
            'label' => $label,
            'content' => $content,
        ];
        if ($id == 'insert') {
            insert('web_other', $data);
        } else {
            update('web_other', $data, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_other()
    {
        ck_uri('admin_web/other');
        $id = $_REQUEST['id'];
        delete('web_other', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_other()
    {
        ck_uri('admin_web/other');
        $id = $_REQUEST['id'];
        $o = db('web_other')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('web_other', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_other()
    {
        ck_uri('admin_web/other');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'web_other.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('web_other');
        $country = db('web_other')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->like('label', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * admin_web/other END
     *=====================================================================*/
    /** =====================================================================
     * admin_web/other_link START
     *=====================================================================*/
    public function other_link()
    {
        ck_uri();
        $this->part_in($this->dir() . 'other_link', '', 'Setting other_link');
    }
    public function save_other_link()
    {
        ck_uri('admin_web/other_link');
        $id = $_REQUEST['id'];
        $label = $_REQUEST['label'];
        $url = $_REQUEST['url'];
        $metode = $_REQUEST['metode'];
        $data = [
            'label' => $label,
            'url' => $url,
            'metode' => $metode,
        ];
        if ($id == 'insert') {
            insert('web_other_link', $data);
        } else {
            update('web_other_link', $data, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_other_link()
    {
        ck_uri('admin_web/other_link');
        $id = $_REQUEST['id'];
        delete('web_other_link', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_other_link()
    {
        ck_uri('admin_web/other_link');
        $id = $_REQUEST['id'];
        $o = db('web_other_link')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('web_other_link', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_other_link()
    {
        ck_uri('admin_web/other_link');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'web_other_link.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('web_other_link');
        $country = db('web_other_link')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->like('label', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * admin_web/other_link END
     *=====================================================================*/
    /** =====================================================================
     * admin_web/berita START
     *=====================================================================*/
    public function berita()
    {
        ck_uri();
        $this->part_in($this->dir() . 'berita', '', 'Setting Berita');
    }
    public function save_berita()
    {
        ck_uri('admin_web/berita');
        $id = $_REQUEST['id'];
        $judul = $_REQUEST['judul'];
        $content = $_POST['content'];
        $time = date('d-m-Y');
        $admin = me();
        $data = [
            'judul' => $judul,
            'content' => $content,
            'time' => $time,
            'admin' => $admin,
        ];
        if ($id == 'insert') {
            insert('web_berita', $data);
        } else {
            update('web_berita', $data, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function thumbnail_berita()
    {
        $id = $_POST['id'];
        $date = date('Ydmhis');
        $tempdir = 'img/web/berita/';
        $o = db('web_berita')->getWhere(['id' => $id], 1)->getRow();

        $data = $_POST["image"];
        $image_array_1 = explode(";", $data);
        $image_array_2 = explode(",", $image_array_1[1]);
        $data = base64_decode($image_array_2[1]);
        $imageName = $tempdir . 'Thumbnail_' . $date . '.png';
        $foto = 'Thumbnail_' . $date . '.png';
        $res = file_put_contents($imageName, $data);
        if ($res) {
            if ($o->img != null) {
                $path = FCPATH . 'img/web/berita/' . $o->img;
                (!file_exists($path)) ?: unlink($path);
            }
            update('web_berita', ['img' => $foto], ['id' => $id]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['errorMsg' => 'Gagal Di Upload']);
        }
    }
    public function del_berita()
    {
        ck_uri('admin_web/berita');
        $id = $_REQUEST['id'];
        $o = db('web_berita')->getWhere(['id' => $id], 1)->getRow();
        if ($o->img != null) {
            $path = FCPATH . 'img/web/berita/' . $o->img;
            (!file_exists($path)) ?: unlink($path);
        }
        delete('web_berita', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_berita()
    {
        ck_uri('admin_web/berita');
        $id = $_REQUEST['id'];
        $o = db('web_berita')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('web_berita', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_berita()
    {
        ck_uri('admin_web/berita');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'web_berita.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('web_berita');
        $country = db('web_berita')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->like('judul', $search)
            ->orLike('time', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * admin_web/berita END
     *=====================================================================*/
    /** =====================================================================
     * HOME START
     *=====================================================================*/
    //=========== admin_web/team START ============
    public function team()
    {
        ck_uri();
        $this->part_in($this->dir() . 'team', '', 'Setting team');
    }
    public function save_team()
    {
        ck_uri('admin_web/team');
        $id = $_REQUEST['id'];
        $type = $_REQUEST['type'];
        $user = $_REQUEST['user'];
        $nama = $_REQUEST['nama'];
        $jk = $_REQUEST['jk'];
        $jabatan = $_REQUEST['jabatan'];
        $desk = $_REQUEST['desk'];
        if ($type == 'BARU') {
            $data = [
                'type' => $type,
                'nama' => $nama,
                'jk' => $jk,
                'jabatan' => $jabatan,
                'desk' => $desk,
            ];
            if ($id == 'insert') {
                $data['id'] = date('YmdHis');
                insert('web_team', $data);
            } else {
                update('web_team', $data, ['id' => $id]);
            }
            echo json_encode(['success' => true]);
        } else {
            $data = [
                'type' => $type,
                'user' => $user,
                'jabatan' => $jabatan,
                'desk' => $desk,
            ];
            if ($id == 'insert') {
                $data['id'] = date('YmdHis');
                insert('web_team', $data);
            } else {
                update('web_team', $data, ['id' => $id]);
            }
            echo json_encode(['success' => true]);
        }
    }
    public function upload_team()
    {
        ck_uri('admin_web/team');
        $id = $_POST['id'];
        $date = date('Ydmhis');
        $tempdir = 'img/avatar/';
        $o = db('web_team')->getWhere(['id' => $id], 1)->getRow();

        $data = $_POST["image"];
        $image_array_1 = explode(";", $data);
        $image_array_2 = explode(",", $image_array_1[1]);
        $data = base64_decode($image_array_2[1]);
        $imageName = $tempdir . 'TEAM_' . $date . '.png';
        $foto = 'TEAM_' . $date . '.png';
        $res = file_put_contents($imageName, $data);
        if ($res) {
            if ($o->foto != null) {
                $path = FCPATH . 'img/avatar/' . $o->foto;
                (!file_exists($path)) ?: unlink($path);
            }
            update('web_team', ['foto' => $foto], ['id' => $id]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['errorMsg' => 'Gagal Di Upload']);
        }
    }
    public function del_team()
    {
        ck_uri('admin_web/team');
        $id = $_REQUEST['id'];
        $o = db('web_team')->getWhere(['id' => $id], 1)->getRow();
        if ($o->img != null) {
            $path = FCPATH . 'img/avatar/' . $o->img;
            (!file_exists($path)) ?: unlink($path);
        }
        delete('web_team', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_team()
    {
        ck_uri('admin_web/team');
        $id = $_REQUEST['id'];
        $o = db('web_team')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('web_team', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_team_us()
    {
        ck_uri('admin_web/team');
        $id = $_REQUEST['id'];
        $o = db('users')->getWhere(['id' => $id], 1)->getRow();
        echo json_encode($o);
    }
    public function get_team()
    {
        ck_uri('admin_web/team');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10000;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'web_team.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('web_team');
        $country = db('web_team')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    //============ admin_web/team END =============
    //=========== admin_web/link START ============
    public function link()
    {
        ck_uri();
        $this->part_in($this->dir() . 'link', '', 'Setting link');
    }
    public function save_link()
    {
        $db = 'web_link';
        $res = false;
        $id = htmlspecialchars($_REQUEST['id']);
        $nama = htmlspecialchars($_REQUEST['nama']);
        $url = htmlspecialchars($_REQUEST['url']);
        $data_in = [
            'nama' => $nama,
            'url' => $url,
        ];
        if ($id == 'insert') {
            if ($_FILES['logo']['name'] != '') {
                $test = explode('.', $_FILES['logo']['name']);
                $extension = end($test);
                if ($extension != 'png' && $extension != 'svg' && $extension != 'gif') {
                    echo json_encode(['errorMsg' => 'Gagal Di Save Extensi Salah. [png , svg , gif] only']);
                    exit;
                }
                $name = $db . '_' . time() . '.' . $extension;
                $location = FCPATH . '/img/link/' . $name;
                $res = move_uploaded_file($_FILES['logo']['tmp_name'], $location);
                $data_in['logo'] = ($res) ? $name : '';
                insert($db, $data_in);
            } else {
                echo json_encode(['errorMsg' => 'Logo Harus Di Sertakan']);
                exit;
            }
        } else {
            if ($_FILES['logo']['name'] != '') {
                $test = explode('.', $_FILES['logo']['name']);
                $extension = end($test);
                if ($extension != 'png' && $extension != 'svg' && $extension != 'gif') {
                    echo json_encode(['errorMsg' => 'Gagal Di Save Extensi Salah. [png , svg , gif] only']);
                    exit;
                }
                $name = $db . '_' . time() . '.' . $extension;
                $location = FCPATH . '/img/link/' . $name;
                $o = db($db)->getWhere(['id' => $id], 1)->getRow();
                if ($o->logo != null) {
                    $path = FCPATH . '/img/link/' . $o->logo;
                    (!fileExists($path)) ?: unlink($path);
                }
                $res = move_uploaded_file($_FILES['logo']['tmp_name'], $location);
                $data_in['logo'] = ($res) ? $name : '';
            }
            update($db, $data_in, ['id' => $id]);
        }
        echo json_encode(['success' => true, 'file' => $data_in['logo']]);
    }
    public function del_link()
    {
        ck_uri('admin_web/link');
        $id = $_REQUEST['id'];
        $o = db('web_link')->getWhere(['id' => $id], 1)->getRow();
        if ($o->img != null) {
            $path = FCPATH . 'img/link/' . $o->img;
            (!file_exists($path)) ?: unlink($path);
        }
        delete('web_link', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_link()
    {
        ck_uri('admin_web/link');
        $id = $_REQUEST['id'];
        $o = db('web_link')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('web_link', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_link()
    {
        ck_uri('admin_web/link');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10000;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'web_link.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('web_link');
        $country = db('web_link')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    //============ admin_web/link END =============
    //========== admin_web/slider START ===========
    public function slider()
    {
        ck_uri();
        $this->part_in($this->dir() . 'slider', '', 'Setting Slider');
    }
    public function save_slider()
    {
        ck_uri('admin_web/slider');
        $id = $_REQUEST['id'];
        if ($_FILES['file']['name'] != '') {
            $test = explode('.', $_FILES['file']['name']);
            $extension = end($test);
            $name = 'Slider_' . time() . '.' . $extension;
            $location = 'img/web/slider/' . $name;
            $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
            if ($res) {
                if ($id == 'insert') {
                    insert('web_slider', ['img' => $name]);
                } else {
                    $o = db('web_slider')->getWhere(['id' => $id], 1)->getRow();
                    if ($o->img != null) {
                        $path = FCPATH . 'img/web/slider/' . $o->img;
                        (!file_exists($path)) ?: unlink($path);
                    }
                    update('web_slider', ['img' => $name], ['id' => $id]);
                }
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['errorMsg' => 'File Gagal Di Upload.']);
            }
        } else {
            echo json_encode(['errorMsg' => 'Tidak Ada File Terdeteksi']);
        }
    }
    public function del_slider()
    {
        ck_uri('admin_web/slider');
        $id = $_REQUEST['id'];
        $o = db('web_slider')->getWhere(['id' => $id], 1)->getRow();
        if ($o->img != null) {
            $path = FCPATH . 'img/web/slider/' . $o->img;
            (!file_exists($path)) ?: unlink($path);
        }
        delete('web_slider', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_slider()
    {
        ck_uri('admin_web/slider');
        $id = $_REQUEST['id'];
        $o = db('web_slider')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('web_slider', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_slider()
    {
        ck_uri('admin_web/slider');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('web_slider');
        $country = db('web_slider')
            ->orderBy('id', 'DESC')
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    //=========== admin_web/slider END ============
    //========= admin_web/visi_misi START ==========
    public function visi_misi()
    {
        ck_uri();
        $this->part_in($this->dir() . 'visi_misi', '', 'Setting Visi Misi');
    }
    public function save_visi_misi()
    {
        ck_uri('admin_web/visi_misi');
        $id = $_REQUEST['id'];
        $role = $_REQUEST['role'];
        $text = $_REQUEST['text'];
        $data = [
            'role' => $role,
            'text' => $text,
        ];
        if ($id == 'insert') {
            insert('web_visi_misi', $data);
        } else {
            update('web_visi_misi', $data, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_visi_misi()
    {
        ck_uri('admin_web/visi_misi');
        $id = $_REQUEST['id'];
        delete('web_visi_misi', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_visi_misi()
    {
        ck_uri('admin_web/visi_misi');
        $id = $_REQUEST['id'];
        $o = db('web_visi_misi')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('web_visi_misi', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_visi_misi()
    {
        ck_uri('admin_web/visi_misi');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('web_visi_misi');
        $country = db('web_visi_misi')
            ->orderBy('role', 'ASC')
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    //========== admin_web/visi_misi END ===========
    //=========== admin_web/media START ============
    public function media()
    {
        ck_uri();
        $this->part_in($this->dir() . 'media', '', 'Setting Slider');
    }
    public function save_media()
    {
        ck_uri('admin_web/media');
        $id = $_REQUEST['id'];
        $code = $_REQUEST['code'];
        update('temp_inc', ['code' => $code], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_media()
    {
        ck_uri('admin_web/media');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = 5;
        $country = db('temp_inc')
            ->orderBy('id', 'ASC')
            ->limit($rows, $offset)
            ->whereIn('id', ['url_facebook', 'url_instagram', 'url_whatsapp', 'url_google_map', 'url_video_profil'])
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    //============ admin_web/media END =============
    /** =====================================================================
     * HOME END
     *=====================================================================*/
}
