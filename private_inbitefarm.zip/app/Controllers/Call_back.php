<?php

namespace App\Controllers;

class Call_back extends BaseController
{
    public function __construct()
    {
        //....
    }
    public function index()
    {
        go();
    }
    public function get_encode()
    {
        $con = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || isset($_ENV['FORCE_HTTPS'])) ? 'https' : 'http';
        $con .= '://' . $_SERVER['HTTP_HOST'];
        $con .= str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
        $x = explode('/', $con);
        $url = 'https://keygen-v1.herokuapp.com/encode';
        // $url = 'http://localhost:3000/encode';
        $data = [
            "data" => 'localhost:8080##20220322',
        ];
        $dt = init_curl($url, $data);
        echo $dt;
    }
    public function get_decode()
    {
        $con = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || isset($_ENV['FORCE_HTTPS'])) ? 'https' : 'http';
        $con .= '://' . $_SERVER['HTTP_HOST'];
        $con .= str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
        $x = explode('/', $con);
        $url = 'https://keygen-v1.herokuapp.com/decode';
        // $url = 'http://localhost:3000/decode';
        $data = [
            "data" => 'VjFkMGFrNVhSbk5pUm1oc1VucHNjRlJVUVRCa01WRjVZMGMxYTAxRWJFWlZWbVIzVTIxV2NtSkVUbFZUU0VKRFdsVmtkMU50VVhkT1ZsWlVWMGRrVFdWclJYY0x6QTQ=',
        ];
        $dt = init_curl($url, $data);
        echo $dt;
    }
}
