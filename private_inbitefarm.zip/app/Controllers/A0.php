<?php

namespace App\Controllers;

class A0 extends BaseController
{
    public function __construct()
    {
        //(me()) ?: go();
    }
    private function dir()
    {
        return 'A0/';
    }
    public function index()
    {
        go();
    }
    public function end_point()
    {
        ck_uri();
    }
}
