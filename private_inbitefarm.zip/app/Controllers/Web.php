<?php

namespace App\Controllers;

class Web extends BaseController
{
    public function __construct()
    {
        helper('url');
    }
    private function dir()
    {
        return 'web/';
    }
    //====================================WEBSITE START======================================
    public function sertifikat()
    {
        return view($this->dir() . 'sertifikat');
    }
    public function index($like = null)
    {
        if (inc('web_status') == 'true') {
            session()->set(['page' => 'home']);
            if ($like == null) {
                $data['id'] = '';
            } else {
                $data['id'] = $like;
            }
            $this->part_web($this->dir() . 'index', $data);
        } else {
            $this->part_login($this->dir() . 'login', '', 'HALAMAN LOGIN');
        }
    }
    public function main($like = null, $kategori = null)
    {
        if ($like != null) {
            if ($kategori != null) {
                if ($kategori == 'xxbaruxx') {
                    $data['item'] = db('produk_data')
                        ->getWhere(['status' => 'true', 'new' => 'Y'])
                        ->getResult();
                } elseif ($kategori == 'xxunggulxx') {
                    $data['item'] = db('produk_data')
                        ->getWhere(['status' => 'true', 'unggul' => 'Y'])
                        ->getResult();
                } else {
                    $data['item'] = db('produk_data')
                        ->getWhere(['status' => 'true', 'kategori' => $kategori])
                        ->getResult();
                }
            } else {
                $data['item'] = db('produk_data')
                    ->like('nama', $like)
                    ->getWhere(['status' => 'true'])
                    ->getResult();
            }
        } else {
            $data['item'] = db('produk_data')
                ->orderBy('kategori', 'RANDOM')
                ->getWhere(['status' => 'true'])
                ->getResult();
        }
        return view('web/main', $data);
    }
    public function selengkapnya($id)
    {
        $data['id'] = $id;
        return view('web/produk_data', $data);
    }
    public function gallery()
    {
        session()->set(['page' => 'gallery']);
        $this->part_web($this->dir() . 'gallery');
    }
    public function produk()
    {
        session()->set(['page' => 'produk']);
        $this->part_web($this->dir() . 'produk');
    }
    // public function ks($id = null)
    // {
    //     session()->set(['page' => 'ks']);
    //     if (empty($id)) {
    //         $this->part_web($this->dir() . 'ks', '', 'HALAMAN KERJA SAMA');
    //     } else {
    //         $o = db('web_kerja_sama')->getWhere(['id' => de64($id)], 1)->getRow();
    //         $view = $o->view + 1;
    //         update('web_kerja_sama', ['view' => $view], ['id' => de64($id)]);
    //         if (empty($o->id)) {
    //             go();
    //         }
    //         $this->part_web($this->dir() . 'ksid', ['o' => $o], 'HALAMAN KERJA SAMA');
    //     }
    // }
    public function berita($id = null)
    {
        session()->set(['page' => 'berita']);
        if (empty($id)) {
            $this->part_web($this->dir() . 'berita', '', 'HALAMAN BERITA');
        } else {
            $o = db('web_berita')->getWhere(['id' => de64($id)], 1)->getRow();
            $view = $o->view + 1;
            update('web_berita', ['view' => $view], ['id' => de64($id)]);
            if (empty($o->id)) {
                go();
            }
            $this->part_web($this->dir() . 'beritaid', ['o' => $o], 'HALAMAN BERITA');
        }
    }
    public function contact()
    {
        session()->set(['page' => 'contact']);
        $this->part_web($this->dir() . 'contact', '', 'HALAMAN CONTACT ADMIN');
    }
    public function link()
    {
        session()->set(['page' => 'link']);
        $this->part_web($this->dir() . 'link', '', 'HALAMAN LINK TERKAIT');
    }
    public function other($id)
    {
        if (!$id) go();
        session()->set(['page' => 'other']);
        $o = db('web_other')->getWhere(['id' => de64($id)], 1)->getRow();
        $this->part_web($this->dir() . 'other', ['id' => $o->id], 'HALAMAN ' . $o->label);
    }
    // public function akreditasi()
    // {
    //     session()->set(['page' => 'akreditasi']);
    //     $this->part_web($this->dir() . 'akreditasi', '', 'HALAMAN AKREDITASI');
    // }
    public function document()
    {
        session()->set(['page' => 'other_link']);
        $this->part_web($this->dir() . 'document', '', 'HALAMAN DOCUMENT');
    }
    public function doc_root($root1 = null, $root2 = null)
    {
        return view($this->dir() . 'doc_root', ['root' => XROOT . $root1]);
    }
    public function slider()
    {
        return view($this->dir() . 'slider');
    }
    //====================================WEBSITE END========================================
    public function biodata($id)
    {
        $ck = num_rows('users', en64('id="' . $id . '"'));
        ($ck > 0) ?: go();
        $data['id'] = $id;
        $this->part_in($this->dir() . 'biodata', $data, 'Biodata');
    }
    public function kuisioner()
    {
        if (req()->getPost('nama') != null) {
            $data = [
                's_nama' => req()->getPost('nama'),
                's_email' => req()->getPost('email'),
                's_hp' => req()->getPost('hp'),
            ];
            session()->set($data);
        }
        return view($this->dir() . 'kuisioner');
    }
    public function login()
    {
        $this->part_login($this->dir() . 'login', '', 'HALAMAN LOGIN');
    }
    public function logout()
    {
        session()->remove('idx');
        session()->setFlashdata('info', 'Anda telah keluar.');
        go('login');
    }
    public function register()
    {
        (inc('register') == 'true') ?: go();
        $this->part_login($this->dir() . 'register', '', 'HALAMAN REGISTRASI');
    }
    public function forgot()
    {
        (inc('forgot') == 'true') ?: go();
        $this->part_login($this->dir() . 'forgot', '', 'HALAMAN LUPA PASSWORD');
    }
}
