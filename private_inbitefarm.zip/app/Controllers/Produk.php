<?php

namespace App\Controllers;

use function PHPUnit\Framework\fileExists;

class Produk extends BaseController
{
    public function __construct()
    {
        //(me()) ?: go();
    }
    private function dir()
    {
        return 'produk/';
    }
    public function index()
    {
        go();
    }

    //========== produk/data START ===========
    public function data($id = null)
    {
        ck_uri('produk/data');
        if ($id == null) {
            if (me() == 1 || me() == '28071986') {
                $this->part_in($this->dir() . 'kategori', '', 'Setting data');
            } else {
                $this->part_in($this->dir() . 'kategori_op', '', 'Setting data');
            }
        } else {
            $data['id'] = $id;
            $this->part_in($this->dir() . 'data', $data, 'Setting data');
        }
    }
    public function data_op($id = null)
    {
        ck_uri('produk/data_op');
        if ($id == null) {
            $this->part_in($this->dir() . 'kategori_op', '', 'Setting data');
        } else {
            $data['id'] = $id;
            $this->part_in($this->dir() . 'data', $data, 'Setting data');
        }
    }
    public function order($status = null)
    {
        ck_uri('produk/order/' . $status);
        $data['status'] = $status;
        $this->part_in($this->dir() . 'order', $data, 'Order data');
    }
    public function proses_order($status = null)
    {
        ck_uri('produk/order/' . $status);
        $id = $_REQUEST['id'];
        if ($status == 'Baru') {
            $sts = 'Proses';
        } else {
            $sts = 'Lunas';
            $o = db('produk_order')->getWhere(['id' => $id])->getRow();
            $x = db('produk_data')->getWhere(['id' => $o->produk_id])->getRow();
            $qty = $x->qty - $o->produk_qty;
            if ($qty < 1) {
                update('produk_data', ['qty' => $qty, 'aksi' => 'Habis'], ['id' => $x->id]);
            } else {
                update('produk_data', ['qty' => $qty], ['id' => $x->id]);
            }
        }
        update('produk_order', ['status' => $sts, 'admin' => me('nama'), 'time_update' => date("d/m/Y H:i")], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function batal_order($status = null)
    {
        ck_uri('produk/order/' . $status);
        $id = $_REQUEST['id'];
        if ($status != 'Baru') {
            $o = db('produk_order')->getWhere(['id' => $id])->getRow();
            $x = db('produk_data')->getWhere(['id' => $o->produk_id])->getRow();
            $qty = $x->qty + $o->produk_qty;
            if ($x->qty < 1) {
                update('produk_data', ['qty' => $qty, 'aksi' => 'Ready'], ['id' => $x->id]);
            } else {
                update('produk_data', ['qty' => $qty], ['id' => $x->id]);
            }
        }
        update('produk_order', ['status' => 'Batal', 'admin' => me('nama'), 'time_update' => date("d/m/Y H:i")], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_order($status = null)
    {
        ck_uri('produk/order/' . $status);
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('produk_order', en64('status="' . $status . '"'));
        if ($status == 'Lunas' || $status == 'Batal') {
            $asc = 'DESC';
        } else {
            $asc = 'ASC';
        }
        $country = db('produk_order')
            ->orderBy('stamp', $asc)
            ->like('id', $search)
            // ->orLike('nama', $search)
            // ->orLike('hp', $search)
            // ->orLike('email', $search)
            // ->orLike('kategori', $search)
            // ->orLike('kode_pack', $search)
            ->limit($rows, $offset)
            ->getWhere(['status' => $status])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    // KATEGORI
    public function save_kategori()
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        $nama = $_REQUEST['nama'];
        $ket = $_REQUEST['ket'];
        $class_a1 = $_REQUEST['class_a1'];
        $class_a2 = $_REQUEST['class_a2'];
        $class_b1 = $_REQUEST['class_b1'];
        $class_b2 = $_REQUEST['class_b2'];
        $class_c1 = $_REQUEST['class_c1'];
        $class_c2 = $_REQUEST['class_c2'];
        $data_in = [
            'nama' => $nama,
            'ket' => $ket,
            'class_a1' => $class_a1,
            'class_a2' => $class_a2,
            'class_b1' => $class_b1,
            'class_b2' => $class_b2,
            'class_c1' => $class_c1,
            'class_c2' => $class_c2,
        ];

        if ($id == 'insert') {
            $data_in['id'] = time();
            $data_in['at_create'] = date("d-m-Y H:i:s");
            insert('produk_kategori', $data_in);
        } else {
            $data_in['at_update'] = date("d-m-Y H:i:s");
            update('produk_kategori', $data_in, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function save_order()
    {
        $produk_id = $_REQUEST['produk_id'];
        $nama = $_REQUEST['nama'];
        $hp = $_REQUEST['hp'];
        $email = $_REQUEST['email'];
        $alamat = $_REQUEST['alamat'];
        $order_qty = $_REQUEST['order_qty'];
        $ket = $_REQUEST['ket'];
        $c1 = num_rows('produk_order', en64('status="Baru" AND produk_id="' . $produk_id . '" AND hp="' . $hp . '"'));
        $c2 = num_rows('produk_order', en64('status="Proses" AND produk_id="' . $produk_id . '" AND hp="' . $hp . '"'));
        if ($c1 > 0 || $c2 > 0) {
            echo 'Maaf !! Sudah ada permintaan seperti ini sebelumnya yg masih dalam proses harap menunggu konfirmasi admin lewat Email atau whatsapp';
            exit;
        }
        $p = db('produk_data')->getWhere(['id' => $produk_id], 1)->getRow();
        $kat = db('produk_kategori')->getWhere(['id' => $p->kategori], 1)->getRow();
        $idr = $p->harga * $order_qty;
        $data_in = [
            'id' => id_order('8'),
            'stamp' => date('YmdHis'),
            'time_order' => date('d-m-Y'),
            'nama' => $nama,
            'hp' => $hp,
            'email' => $email,
            'alamat' => $alamat,
            'idr' => $idr,
            'kategori' => $kat->nama,
            'produk_id' => $produk_id,
            'kode_pack' => $p->nama,
            'produk_qty' => $order_qty,
            'ket' => $ket,
        ];
        insert('produk_order', $data_in);
        echo '200';
    }
    public function del_kategori()
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        delete('produk_kategori', ['id' => $id]);
        $oo = db('produk_data')->getWhere(['kategori' => $id])->getResult();
        foreach ($oo as $o) {
            if ($o->img != null) {
                $path = FCPATH . 'img/web/produk/' . $o->img;
                (!file_exists($path)) ?: unlink($path);
            }
        }
        delete('produk_data', ['kategori' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_kategori()
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        $o = db('produk_kategori')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('produk_kategori', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_kategori()
    {
        ck_uri('produk/data');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('produk_kategori');
        $country = db('produk_kategori')
            ->orderBy('id', 'ASC')
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    // DATA
    public function save_data($kategori)
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        $nama = $_REQUEST['nama'];
        $harga = $_REQUEST['harga'];
        $new = $_REQUEST['new'];
        $unggul = $_REQUEST['unggul'];
        $tgl_ready = $_REQUEST['tgl_ready'];
        $lubang = $_REQUEST['lubang'];
        $min_order = $_REQUEST['min_order'];
        $class = $_REQUEST['class'];
        $desk = $_REQUEST['desk'];

        $k = db('produk_kategori')->getWhere(['id' => $kategori], 1)->getRow();
        $s1 = 'class_' . strtolower($class) . '1';
        $s2 = 'class_' . strtolower($class) . '2';
        $qty = $lubang / $k->$s1;
        $qty = floor($qty);
        $satuan = $k->$s2;
        $tgl_a = date("Ymd", strtotime($tgl_ready));
        if (date("Ymd") >= $tgl_a) {
            $aksi = 'Ready';
        } else {
            $aksi = 'Semai';
        }
        if ($qty < 1) {
            $aksi = 'Habis';
        }
        $data_in = [
            'nama' => $nama,
            'harga' => $harga,
            'satuan' => $satuan,
            'new' => $new,
            'unggul' => $unggul,
            'tgl_ready' => $tgl_ready,
            'lubang' => $lubang,
            'min_order' => $min_order,
            'class' => $class,
            'aksi' => $aksi,
            'qty_awal' => $qty,
            'qty' => $qty,
            'desk' => $desk,
        ];

        if ($id == 'insert') {
            if ($_FILES['file']['name'] != '') {
                $test = explode('.', $_FILES['file']['name']);
                $extension = end($test);
                $name = 'gallery_' . time() . '.' . $extension;
                $location = 'img/web/produk/' . $name;
                $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
                if ($res) {
                    $data_in['img'] = $name;
                }
            } else {
                echo json_encode(['errorMsg' => 'File Gambar Tidak di temukan.']);
                exit;
            }
            $data_in['kategori'] = $kategori;
            $data_in['at_create'] = date("d-m-Y H:i:s");
            insert('produk_data', $data_in);
        } else {
            $o = db('produk_data')->getWhere(['id' => $id], 1)->getRow();
            // if ($o->qty == $qty) {
            //     echo json_encode(['errorMsg' => 'Maaf !! Jika Stok Berkurang. hanya dapat Update Gambar']);
            //     exit;
            // }
            if ($_FILES['file']['name'] != '') {
                $test = explode('.', $_FILES['file']['name']);
                $extension = end($test);
                $name = 'gallery_' . time() . '.' . $extension;
                $location = 'img/web/produk/' . $name;
                $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
                if ($res) {
                    $data_in['img'] = $name;
                }
                if ($o->img != null) {
                    $path = FCPATH . 'img/web/produk/' . $o->img;
                    (!file_exists($path)) ?: unlink($path);
                }
            }
            $data_in['at_update'] = date("d-m-Y H:i:s");
            update('produk_data', $data_in, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_data()
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        $o = db('produk_data')->getWhere(['id' => $id], 1)->getRow();
        if ($o->img != null) {
            $path = FCPATH . 'img/web/produk/' . $o->img;
            (!file_exists($path)) ?: unlink($path);
        }
        delete('produk_data', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function status_data()
    {
        ck_uri('produk/data');
        $id = $_REQUEST['id'];
        $o = db('produk_data')->getWhere(['id' => $id], 1)->getRow();
        $status = ($o->status == 'true') ? 'false' : 'true';
        update('produk_data', ['status' => $status], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_data($id)
    {
        ck_uri('produk/data');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('produk_data', en64('kategori=' . $id));
        $country = db('produk_data')
            ->orderBy('id', 'DESC')
            ->where('kategori', $id)
            ->like('nama', $search)
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    //=========== produk/data END ============

    //========== produk/top START ===========
    public function top()
    {
        ck_uri();
        if (req()->getPost('web_produk_text_color') != null) {
            $web_produk_label = req()->getPost('web_produk_label');
            $web_produk_text_color = req()->getPost('web_produk_text_color');
            update('temp_inc', ['code' => $web_produk_label], ['id' => 'web_produk_label']);
            update('temp_inc', ['code' => $web_produk_text_color], ['id' => 'web_produk_text_color']);
            session()->setFlashdata('info', 'Data Berhasil Di Update');
        }
        $this->part_in($this->dir() . 'top', '', 'Setting top');
    }
    //=========== produk/top END ============

}
