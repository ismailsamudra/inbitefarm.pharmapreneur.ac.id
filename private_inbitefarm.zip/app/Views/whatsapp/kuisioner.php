<link rel="stylesheet" href="<?= XROOT ?>script/summernote/summernote-bs4.min.css">
<script src="<?= XROOT ?>script/summernote/summernote-bs4.min.js"></script>
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5><small><i class="fab fa-whatsapp mr-2"></i> <?= strtoupper("Kuisioner Template") ?></small>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<div class="container mt-2">

    <div class="col-12">
        <div class="row">
            <div class="col-12 my-2">
                <div id="notif" class="mb-2"></div>
                <div class="row">

                </div>
            </div>

            <div class="col-md-12 mb-2">
                <strong>NB : KODE UNTUK NAMA USER : #NAMA# </strong>
                <br>
                <br>
                <br>
                <div class="card bg-1">
                    <div class="col">
                        <small>
                            <strong>
                                <x>
                                    WHATSAPP KUISIONER TEXT TEMPLATE
                                    <a href="javascript:void(0);" id="bt_e_wa_endpoint" class="float-right" onclick="edit()"><i class="fa fa-edit text-white" title="Edit"></i></a>
                                </x>
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-12">

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>TEXT</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <textarea name="" id="" cols="30" rows="5" class="form-control my-2" readonly><?= inc('wa_kuisioner_text') ?></textarea>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
<!-- BODY END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="mtext" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Text Template</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" <small>TEXT</small>
                <textarea name="text" id="text" class="form-control" rows="6"><?= inc('wa_kuisioner_text') ?></textarea>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="save()" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>SAVE</a>
            </div>
        </div>

    </div>
</div>
</div>
<!-- End Modal 1-->
<script type="text/javascript">
    function edit() {
        $("#mtext").modal('show');
    }

    function save() {
        var url = '<?= XROOT ?>whatsapp/save_kuisioner';
        var text = document.getElementById('text').value;
        $.post(url, {
            text
        }, function(result) {
            if (result.success) {
                $('mtext').modal('hide');
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Berhasil di Ubah.'
                });
                window.location.reload();
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
            $("#load").modal('hide');
        }, 'json');
    }
</script>