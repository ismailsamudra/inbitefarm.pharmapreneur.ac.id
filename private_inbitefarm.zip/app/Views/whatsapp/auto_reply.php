<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a href="javascript:void(0);" onclick="add();" class="btn-sm bt-1 float-left" title="TAMBAH"><i class="fa fa-plus"></i></a>
            <h5>
                <a href="" style="color: <?= color('primary-b') ?>;">
                    <small>
                        <strong>
                            <i class="fab fa-whatsapp mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                        </strong>
                    </small>
                </a>
                <a href="javascript:void(0);" onclick="$('#dguser1').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-6 mb-2 mt-2 table-responsive">
        <div class="row">
            <div class="col-12 mb-2">
                <div class="card col bg-1">
                    <x>
                        <small><strong>REPLY COSTUME</strong></small>
                        <a href="javascript:void(0);" onclick="add();" class="pri-b float-right"><small><strong>TAMBAH</strong></small></a>
                    </x>
                </div>
            </div>
            <div class="col-12">
                <center>
                    <table id="dguser1" toolbar="" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="true" pagination="true" url="<?= XROOT ?>whatsapp/get_auto_reply" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>
        </div>

    </div>
    <div class="col-md-6 mb-2 mt-2 table-responsive">
        <div class="col-12 mb-2">
            <div class="card col bg-1">
                <x>
                    <small><strong>CHATING APAPUN SELAIN COSTUME</strong></small>
                </x>
            </div>
        </div>
        <div class="col-12 mb-2">
            <center>
                <table id="dguser0" toolbar="" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="false" pagination="false" url="<?= XROOT ?>whatsapp/get_auto_reply0">
                    <thead>
                        <tr>
                            <th field="pur_res" width="100%" formatter="show_res"></th>
                        </tr>
                    </thead>
                </table>
            </center>
        </div>
        <div class="container">
            <div class="">
                <strong>
                    NB :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Edit Data
                <hr>
                Jika ingin menyertakan file harus membuat Data terlebih dahulu
                lalu klick kanan jika desktop
                dan sentuh tahan jika HP pada baris data lalu pilih sertakan file<br>
                Extensi Di sesuaikan Extensi yg di terima whatsapp,<br>
                Namun Ada beberapa Estensi yg dapat menonaktifkan Text atau caption.
                <hr>
            </div>
            <br>
            <br>
            <br>
        </div>
        <center>
            <i class="fab fa-whatsapp fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<style>
    .consta>input {
        display: none;
    }
</style>
<!-- RIGHT BUTTON START -->
<div id="mm1" class="easyui-menu" style="border: 0px;">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="update('1');"><i class="far fa-edit mr-2"></i> Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="test('1');"><i class="fa fa-paper-plane mr-2"></i> Tes Kirim</a>
    <!-- <span class=""> -->
    <label for="btn_logo_p1" class="consta">
        <a class="btn-sm form-control" plain="true"><i class="fa fa-paperclip mr-2"></i>
            Sertakan File
        </a>
        <input type="file" name="btn_logo_p" id="btn_logo_p1" onchange="upload('1');" accept="*/*">
    </label>
    <!-- </span> -->
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="status('1');"><span id="btn-status1"></span></a>
    <a id="btnhfile1"></a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser('data','1');"><i class="fa fa-trash mr-2 text-danger"></i> Hapus Data</a>
</div>
<div id="mm0" class="easyui-menu" style="border: 0px;">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="update('0');"><i class="far fa-edit mr-2"></i> Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="test('0');"><i class="fa fa-paper-plane mr-2"></i> Tes Kirim</a>
    <!-- <span class=""> -->
    <label for="btn_logo_p0" class="consta">
        <a class="btn-sm form-control" plain="true"><i class="fa fa-paperclip mr-2"></i>
            Sertakan File
        </a>
        <input type="file" name="btn_logo_p" id="btn_logo_p0" onchange="upload('0');" accept="*/*">
    </label>
    <!-- </span> -->
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="status('0');"><span id="btn-status0"></span></a>
    <a id="btnhfile0"></a>
</div>
<!-- RIGHT BUTTON END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="fm" method="post">
                    <input type="hidden" id="id" name="id">
                    <small>KEYWORD</small>
                    <input type="text" class="form-control" name="alias" id="alias">
                    <small>RESPON</small>
                    <textarea name="respon" id="respon" cols="30" rows="4" class="form-control"></textarea>
                </form>
            </div>
            <div class="modal-footer">
                <div id="btns"></div>
            </div>
        </div>
    </div>
</div>
<!-- End Modal 1-->
<!-- Start Modal 1 -->
<div class="modal fade" id="send" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fa fa-paper-plane mr-2"></i>Tes Kirim</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="fm2" method="post">
                    <strong>Keyword : </strong><small id="lb_test"></small>
                    <br>
                    <small>Kepada</small>
                    <input type="text" class="form-control" placeholder="No.Whatsapp" name="to" id="to">
                </form>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0)" onclick="send();" class="btn btn-outline-dark btn-sm"><i class="far fa-paper-plane mr-2"></i>Kirim</a>
            </div>
        </div>
    </div>
</div>
<!-- End Modal 1-->

<script type="text/javascript">
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            var file = (row.file == '') ? 'Tidak Ada' : `<a href="<?= XROOT ?>file/wa_media/` + row.file + `" target="_blank"><small><strong>` + row.file + `</strong></small></a>`;
            var status = (row.status == 'true') ? 'ENABLE' : 'DISABLE';
            var t = `
            <div class="card col mt-1">
            <div class="row">
                <div class="col-md-2">
                    <strong>KEYWORD</strong>
                </div>
                <div class="col-md-10">
                    : ` + row.alias + `
                </div>
            </div>
            </div>
            <div class="card col">
            <x>
            <strong>RESPON TEXT</strong>
            <small class="float-right"><strong>` + status + `</strong></small>
            </x>
            </div>
            <textarea cols="30" rows="4" class="form-control" readonly>` + row.respon + `</textarea>
            <div class="card col mb-1">
            <div class="row">
                <div class="col-md-4">
                    <strong>RESPON FILE</strong>
                </div>
                <div class="col-md-8">
                    : ` + file + `
                </div>
            </div>
            </div>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        $("#head").html('<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Tambah Data</h5>')
        $("#btns").html('<a href="javascript:void(0)" onclick="save(`1`);" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>')
        document.getElementById("id").value = 'insert';
        $('#modal').modal('show');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function update(val) {
        var row = $('#dguser' + val).datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            $("#head").html('<h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Data</h5>')
            $("#btns").html('<a href="javascript:void(0)" onclick="save(`' + val + '`);" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>')
            $('#modal').modal('show');
        } else {
            msg('Error', 'Data tidak di pilih');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function test(dt) {
        var row = $('#dguser' + dt).datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            $('#lb_test').html(row.alias);
            $('#send').modal('show');
        } else {
            msg('Error', 'Data tidak di pilih');
        }
    }

    function send() {
        ($('#to').val() == '') ? [msg('Error', 'No.Whatsapp harus di isi'), $('#to').focus(), exit] : '';
        $("#load").modal({
            backdrop: "static"
        });
        var url = '<?= XROOT ?>whatsapp/tes_kirim/wa_reply/respon';
        var id = $("#id").val();
        var to = $("#to").val();
        $.post(url, {
            to,
            id
        }, function(result) {
            if (result.success) {
                $('#send').modal('hide');
                msg('Success !', 'Berhasil di Kirim.');
            } else {
                msg('Error', result.errorMsg);
            }
            $("#load").modal('hide');
        }, 'json');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save(tb) {
        ($('#alias').val() == '') ? [msg('Error', 'KEYWORD harus di isi'), $('#alias').focus(), exit] : '';
        ($('#respon').val() == '') ? [msg('Error', 'RESPON harus di isi'), $('#respon').focus(), exit] : '';
        $('#fm').form('submit', {
            url: '<?= XROOT ?>whatsapp/crud_auto_reply',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.errorMsg) {
                    msg('Error', result.errorMsg);
                } else {
                    $('#modal').modal('hide');
                    $('#dguser' + tb).datagrid('reload');
                    msg('Success !', 'Berhasil');
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function status(tb) {
        var row = $('#dguser' + tb).datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Mengubah Status data ini ?<br>KEYWORD : ' + row.alias, function(r) {
                if (r) {
                    url = '<?= XROOT ?>whatsapp/status_auto_reply';
                    $.post(url, {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser' + tb).datagrid('reload');
                            msg('Success !', 'Status Berhasil Di Ubah');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser(data, tb) {
        var row = $('#dguser' + tb).datagrid('getSelected');
        if (row) {
            if (data == 'file') {
                $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus File data ini ?<br>KEYWORD : ' + row.alias, function(r) {
                    if (r) {
                        url = '<?= XROOT ?>whatsapp/del_auto_reply';
                        $.post(url, {
                            id: row.id,
                            data
                        }, function(result) {
                            if (result.success) {
                                $('#dguser' + tb).datagrid('reload');
                                msg('Success !', 'FILE Berhasil Di Hapus');
                            } else {
                                msg('Error', result.errorMsg);
                            }
                        }, 'json');
                    }
                });
            } else {
                $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>KEYWORD : ' + row.alias, function(r) {
                    if (r) {
                        url = '<?= XROOT ?>whatsapp/del_auto_reply';
                        $.post(url, {
                            id: row.id,
                            data
                        }, function(result) {
                            if (result.success) {
                                $('#dguser' + tb).datagrid('reload');
                                msg('Success !', 'DATA Berhasil Di Hapus');
                            } else {
                                msg('Error', result.errorMsg);
                            }
                        }, 'json');
                    }
                });
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser0').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                if (row) {
                    document.getElementById('idx').value = row.id;
                    if (row.status == 'true') {
                        $("#btn-status0").html('<i class="fa fa-times text-danger mr-2"></i>Disable');
                    } else {
                        $("#btn-status0").html('<i class="fa fa-check text-success mr-2"></i>Enable');
                    }
                    if (row.file == '') {
                        $("#btnhfile0").html('');
                    } else {
                        $("#btnhfile0").html(`<a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser('file','0');"><i class="fa fa-trash mr-2 text-primary"></i> Hapus File</a>`);
                    }
                } else {
                    msg('Error', 'Harus memilih baris data');
                }
                $('#mm0').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                update('0');
            },
            rowStyler: function(index, row) {
                if (row.status == 'false') {
                    return 'font-weight:bold;background-color: #e60e11;color:#000;';
                }
            }

        })

    })
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser1').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                if (row) {
                    document.getElementById('idx').value = row.id;
                    if (row.status == 'true') {
                        $("#btn-status1").html('<i class="fa fa-times text-danger mr-2"></i>Disable');
                    } else {
                        $("#btn-status1").html('<i class="fa fa-check text-success mr-2"></i>Enable');
                    }
                    if (row.file == '') {
                        $("#btnhfile1").html('');
                    } else {
                        $("#btnhfile1").html(`<a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser('file','1');"><i class="fa fa-trash mr-2 text-primary"></i> Hapus File</a>`);
                    }
                } else {
                    msg('Error', 'Harus memilih baris data');
                }
                $('#mm1').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                update('1');
            },
            rowStyler: function(index, row) {
                if (row.status == 'false') {
                    return 'font-weight:bold;background-color: #e60e11;color:#000;';
                }
            }

        })

    })
    //-----------------------------------------end
    //===========================================
    function upload(dt) {
        var id = document.getElementById('idx').value;
        var url = '<?= XROOT ?>whatsapp/upload_media/wa_reply/' + id;
        var property = document.getElementById('btn_logo_p' + dt).files[0];
        var image_name = property.name;
        var image_extension = image_name.split('.').pop().toLowerCase();
        var e = image_extension;
        if (e == 'exe' || e == 'jar' || e == 'bin') {
            msg('Error', 'Extensi Salah.');
            exit;
        }
        var form_data = new FormData();
        form_data.append("file", property);

        $.ajax({
            url: url,
            method: 'POST',
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                $('#dguser' + dt).datagrid('reload');
                msg('Success !', 'File Berhasil Di Upload');
            },
            error: function(err) {
                msg('Error.', err)
            }
        });
    }
    //===========================================
    $('#to').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
</script>