<?php
$ee = db('engine')->getWhere(['sync' => '0'])->getResult();
foreach ($ee as $o) {
    echo '<input type="hidden" value="' . $o->level_name . '.' . $o->akses_name . '" id="' . $o->akses . '">';
}
?>
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a href="javascript:void(0);" onclick="add();" class="btn-sm bt-1 float-left" title="TAMBAH"><i class="fa fa-plus"></i></a>
            <h5>
                <a href="" style="color: <?= color('primary-b') ?>;">
                    <small>
                        <strong>
                            <i class="fab fa-whatsapp mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                        </strong>
                    </small>
                </a>
                <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-6 mb-2 mt-2 table-responsive">
        <div class="row">
            <div class="col-12 mb-2">
                <div class="card col bg-1">
                    <x>
                        <small><strong>DATA</strong></small>
                        <a href="javascript:void(0);" onclick="add();" class="pri-b float-right"><small><strong>TAMBAH</strong></small></a>
                    </x>
                </div>
            </div>
            <div class="col-12">
                <center>
                    <table id="dguser" toolbar="#toolbarCustomer" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="true" pagination="true" url="<?= XROOT ?>whatsapp/get_broadcast" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>
        </div>

    </div>
    <div class="col-md-6 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    NB :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Edit Data
                <hr>
                Jika ingin menyertakan file harus membuat Data terlebih dahulu
                lalu klick kanan jika desktop
                dan sentuh tahan jika HP pada baris data lalu pilih sertakan file<br>
                Extensi Di sesuaikan Extensi yg di terima whatsapp,<br>
                Namun Ada beberapa Estensi yg dapat menonaktifkan Text atau caption.
                <hr>
            </div>
            <br>
            <br>
            <br>
        </div>
        <center>
            <i class="fab fa-whatsapp fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- TOOLBAR START -->
<div id="toolbarCustomer">
    <div class="row">
        <div class="col-md-8">
            <!---------SEARCH BOX START--------->
            <input id="searchCustomer" class="easyui-searchbox" data-options="prompt:'Cari..',searcher:doSearchCustomer,
            inputEvents: $.extend({}, $.fn.searchbox.defaults.inputEvents, {
                keyup: function(e){
                    var t = $(e.data.target);
                    var opts = t.searchbox('options');
                    t.searchbox('setValue', $(this).val());
                    opts.searcher.call(t[0],t.searchbox('getValue'),t.searchbox('getName'));
                }
            })
        " style="width:100%;"></input>
            <script>
                //-----------------------------------------start
                function doSearchCustomer() {
                    $('#dguser').datagrid('load', {
                        search_customer: $('#searchCustomer').val()
                    });
                }
                //-----------------------------------------end
            </script>
            <!---------SEARCH BOX END----------->
        </div>
    </div>
</div>
<!-- TOOLBAR END -->
<style>
    .consta>input {
        display: none;
    }
</style>
<!-- RIGHT BUTTON START -->
<div id="mm1" class="easyui-menu" style="border: 0px;">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="update();"><i class="far fa-edit mr-2"></i> Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="copy_data();"><i class="far fa-copy mr-2"></i> Copy</a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="test();"><i class="fa fa-paper-plane mr-2"></i> Tes Kirim</a>
    <!-- <span class=""> -->
    <label for="btn_logo_p" class="consta">
        <a class="btn-sm form-control" plain="true"><i class="fa fa-paperclip mr-2"></i>
            Sertakan File
        </a>
        <input type="file" name="btn_logo_p" id="btn_logo_p" onchange="upload();" accept="*/*">
    </label>
    <!-- </span> -->
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="status();"><span id="btn-status1"></span></a>
    <a id="btnhfile1"></a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser('data');"><i class="fa fa-trash mr-2 text-danger"></i> Hapus Data</a>
</div>
<!-- RIGHT BUTTON END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body rol-300">
                <form id="fm" method="post">
                    <input type="hidden" id="id" name="id">
                    <small>KEPADA <small>[ Berdasarkan Akses ]</small></small>
                    <select name="akses" id="akses" class="form-control">
                        <?php
                        foreach ($ee as $o) {
                            echo '<option value="' . $o->akses . '">' . $o->level_name . '.' . $o->akses_name . '</option>';
                        }
                        ?>
                    </select>
                    <small>JENIS KIRIM</small>
                    <select name="jenis" id="jenis" class="form-control">
                        <option value="SEKALI">SEKALI</option>
                        <option value="TIAP_HARI">TIAP_HARI</option>
                        <option value="TIAP_BULAN">TIAP_BULAN</option>
                        <option value="TIAP_TAHUN">TIAP_TAHUN</option>
                    </select>
                    <small>TANGGAL KIRIM</small>
                    <input type="date" class="form-control" name="tgl" id="tgl">
                    <small>JAM KIRIM</small>
                    <input type="time" class="form-control" name="jam" id="jam">
                    <small>TEXT</small>
                    <textarea name="text" id="text" cols="30" rows="4" class="form-control"></textarea>
                </form>
            </div>
            <div class="modal-footer">
                <div id="btns"></div>
            </div>
        </div>
    </div>
</div>
<!-- End Modal 1-->
<!-- Start Modal 1 -->
<div class="modal fade" id="send" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fa fa-paper-plane mr-2"></i>Tes Kirim</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="fm2" method="post">
                    <strong>ID : </strong><small id="lb_test"></small>
                    <br>
                    <small>Kepada</small>
                    <input type="text" class="form-control" placeholder="No.Whatsapp" name="to" id="to">
                </form>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0)" onclick="send();" class="btn btn-outline-dark btn-sm"><i class="far fa-paper-plane mr-2"></i>Kirim</a>
            </div>
        </div>
    </div>
</div>
<!-- End Modal 1-->
<!-- Start Modal 1 -->
<div class="modal fade" id="copy" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fa fa-copy mr-2"></i>Copy Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="fm3" method="post">
                    <input type="hidden" id="idcopy" name="idcopy">
                    <small>KEPADA <small>[ Berdasarkan Akses ]</small></small>
                    <select name="akses2" id="akses2" class="form-control">
                        <?php
                        foreach ($ee as $o) {
                            echo '<option value="' . $o->akses . '">' . $o->level_name . '.' . $o->akses_name . '</option>';
                        }
                        ?>
                    </select>
                </form>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0)" onclick="paste_data();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>
            </div>
        </div>
    </div>
</div>
<!-- End Modal 1-->
<script type="text/javascript">
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            var file = (row.file == '') ? 'Tidak Ada' : `<a href="<?= XROOT ?>file/wa_media/` + row.file + `" target="_blank"><small><strong>` + row.file + `</strong></small></a>`;
            var status = (row.status == 'true') ? 'ENABLE' : 'DISABLE';
            var t = `
            <div class="card col mt-1">
            <div class="row mt-2">
                <div class="col-md-4">
                    <strong>ID</strong>
                </div>
                <div class="col-md-8">
                    : ` + row.id + `
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <strong>KEPADA</strong>
                </div>
                <div class="col-md-8">
                    : ` + document.getElementById(row.akses).value + `
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <strong>WAKTU KIRIM</strong>
                </div>
                <div class="col-md-8">
                    : ` + row.tgl + ` ` + row.jam + `
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <strong>JENIS KIRIM</strong>
                </div>
                <div class="col-md-8">
                    : ` + row.jenis + `
                </div>
            </div>
            <div class="row mb-2">
                <div class="col-md-4">
                    <strong>FILE</strong>
                </div>
                <div class="col-md-8">
                    : ` + file + `
                </div>
            </div>
            </div>
            <div class="card col">
            <x>
            <strong>TEXT</strong>
            <small class="float-right"><strong>` + status + `</strong></small>
            </x>
            </div>
            <textarea cols="30" rows="4" class="form-control mb-1" readonly>` + row.text + `</textarea>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        $('#jenis').val('SEKALI');
        $("#head").html('<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Tambah Data</h5>')
        $("#btns").html('<a href="javascript:void(0)" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>')
        document.getElementById("id").value = 'insert';
        $('#modal').modal('show');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function copy_data() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            document.getElementById("idcopy").value = row.id;
            $('#copy').modal('show');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function update() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            $("#head").html('<h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Data</h5>')
            $("#btns").html('<a href="javascript:void(0)" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>')
            $('#modal').modal('show');
        } else {
            msg('Error', 'Data tidak di pilih');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function test() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            $('#lb_test').html(row.id);
            $('#send').modal('show');
        } else {
            msg('Error', 'Data tidak di pilih');
        }
    }

    function send() {
        ($('#to').val() == '') ? [msg('Error', 'No.Whatsapp harus di isi'), $('#to').focus(), exit] : '';
        $("#load").modal({
            backdrop: "static"
        });
        var url = '<?= XROOT ?>whatsapp/tes_kirim/wa_broadcast/text';
        var id = $("#id").val();
        var to = $("#to").val();
        $.post(url, {
            to,
            id
        }, function(result) {
            if (result.success) {
                $('#send').modal('hide');
                msg('Success !', 'Berhasil di Kirim.');
            } else {
                msg('Error', result.errorMsg);
            }
            $("#load").modal('hide');
        }, 'json');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        (document.getElementById('akses').value == '') ? [msg('Error', 'Akses harus di pilih'), $('#akses').focus(), exit] : '';
        (document.getElementById('jenis').value == '') ? [msg('Error', 'jenis harus di pilih'), $('#jenis').focus(), exit] : '';
        ($('#tgl').val() == '') ? [msg('Error', 'tgl harus di isi'), $('#tgl').focus(), exit] : '';
        ($('#jam').val() == '') ? [msg('Error', 'jam harus di isi'), $('#jam').focus(), exit] : '';
        ($('#text').val() == '') ? [msg('Error', 'text harus di isi'), $('#text').focus(), exit] : '';
        $('#fm').form('submit', {
            url: '<?= XROOT ?>whatsapp/crud_broadcast',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.errorMsg) {
                    msg('Error', result.errorMsg);
                } else {
                    $('#modal').modal('hide');
                    $('#dguser').datagrid('reload');
                    msg('Success !', 'Berhasil');
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function paste_data() {
        (document.getElementById('akses2').value == '') ? [msg('Error', 'Akses harus di pilih'), $('#akses2').focus(), exit] : '';
        $('#fm3').form('submit', {
            url: '<?= XROOT ?>whatsapp/paste_broadcast',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.errorMsg) {
                    msg('Error', result.errorMsg);
                } else {
                    $('#copy').modal('hide');
                    $('#dguser').datagrid('reload');
                    msg('Success !', 'Berhasil di copy');
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function status() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Mengubah Status data ini ?<br>ID : ' + row.id, function(r) {
                if (r) {
                    url = '<?= XROOT ?>whatsapp/status_broadcast';
                    $.post(url, {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Status Berhasil Di Ubah');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser(data) {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            if (data == 'file') {
                $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus File data ini ?<br>ID : ' + row.id, function(r) {
                    if (r) {
                        url = '<?= XROOT ?>whatsapp/del_broadcast';
                        $.post(url, {
                            id: row.id,
                            data
                        }, function(result) {
                            if (result.success) {
                                $('#dguser').datagrid('reload');
                                msg('Success !', 'FILE Berhasil Di Hapus');
                            } else {
                                msg('Error', result.errorMsg);
                            }
                        }, 'json');
                    }
                });
            } else {
                $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>ID : ' + row.id, function(r) {
                    if (r) {
                        url = '<?= XROOT ?>whatsapp/del_broadcast';
                        $.post(url, {
                            id: row.id,
                            data
                        }, function(result) {
                            if (result.success) {
                                $('#dguser').datagrid('reload');
                                msg('Success !', 'DATA Berhasil Di Hapus');
                            } else {
                                msg('Error', result.errorMsg);
                            }
                        }, 'json');
                    }
                });
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                if (row) {
                    document.getElementById('idx').value = row.id;
                    if (row.status == 'true') {
                        $("#btn-status1").html('<i class="fa fa-times text-danger mr-2"></i>Disable');
                    } else {
                        $("#btn-status1").html('<i class="fa fa-check text-success mr-2"></i>Enable');
                    }
                    if (row.file == '') {
                        $("#btnhfile1").html('');
                    } else {
                        $("#btnhfile1").html(`<a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser('file','1');"><i class="fa fa-trash mr-2 text-primary"></i> Hapus File</a>`);
                    }
                } else {
                    msg('Error', 'Harus memilih baris data');
                }
                $('#mm1').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                update('1');
            },
            rowStyler: function(index, row) {
                if (row.status == 'false') {
                    return 'font-weight:bold;background-color: #e60e11;color:#000;';
                }
            }

        })

    })
    //-----------------------------------------end
    //===========================================
    function upload() {
        var id = document.getElementById('idx').value;
        var url = '<?= XROOT ?>whatsapp/upload_media/wa_broadcast/' + id;
        var property = document.getElementById('btn_logo_p').files[0];
        var image_name = property.name;
        var image_extension = image_name.split('.').pop().toLowerCase();
        var e = image_extension;
        if (e == 'exe' || e == 'jar' || e == 'bin') {
            msg('Error', 'Extensi Salah.');
            exit;
        }
        var form_data = new FormData();
        form_data.append("file", property);

        $.ajax({
            url: url,
            method: 'POST',
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                $('#dguser').datagrid('reload');
                msg('Success !', 'File Berhasil Di Upload');
            },
            error: function(err) {
                msg('Error.', err)
            }
        });
    }
    //===========================================
    $('#to').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
    setInterval(set_in, 1000);

    function set_in() {
        $.get('<?= XROOT ?>whatsapp/auth_broadcast');
    }
</script>