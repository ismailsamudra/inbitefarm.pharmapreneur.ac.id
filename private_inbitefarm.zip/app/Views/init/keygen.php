<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5>
                <a href="" style="color: <?= color('primary-b') ?>;">
                    <small>
                        <strong>
                            <i class="fa fa-key mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                        </strong>
                    </small>
                </a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->

<!-- BODY START -->
<div class="container mt-4">
    <hr>
    <div class="row">
        <div class="col-md-12 mb-2">
            <strong><u>Password Has Generate</u><a href="javascript:void(0);" onclick="kosong('reshas');" class="btn btn-sm" title="Clear"><i class="fa fa-sync text-info"></i></a></strong>
        </div>
        <div class="col-md-2">
            <a href="javascript:void(0);" onclick="generate('has','reshas');" class="btn btn-outline-primary d-block mb-2">
                Generate<i class="fa fa-arrow-right ml-2"></i>
            </a>
        </div>
        <div class="col-md-10">
            <textarea id="reshas" cols="30" rows="1" class="form-control"></textarea>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-12 mb-2">
            <strong><u>Md5 Generate</u><a href="javascript:void(0);" onclick="kosong('resmd5');" class="btn btn-sm" title="Clear"><i class="fa fa-sync text-info"></i></a></strong>
        </div>
        <div class="col-md-2">
            <a href="javascript:void(0);" onclick="generate('md5','resmd5');" class="btn btn-outline-primary d-block mb-2">
                Generate<i class="fa fa-arrow-right ml-2"></i>
            </a>
        </div>
        <div class="col-md-10">
            <textarea id="resmd5" cols="30" rows="1" class="form-control"></textarea>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-12 mb-2">
            <strong><u>API Key Generate</u><a href="javascript:void(0);" onclick="kosong('resapi');" class="btn btn-sm" title="Clear"><i class="fa fa-sync text-info"></i></a></strong>
        </div>
        <div class="col-md-2">
            <a href="javascript:void(0);" onclick="generate('api','resapi');" class="btn btn-outline-primary d-block mb-2">
                Generate<i class="fa fa-arrow-right ml-2"></i>
            </a>
        </div>
        <div class="col-md-10">
            <textarea id="resapi" cols="30" rows="1" class="form-control" readonly></textarea>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-12 mb-2">
            <strong><u>Base64 Generate</u><a href="javascript:void(0);" onclick=" kosong('res1');" class="btn btn-sm" title="Clear"><i class="fa fa-sync text-info"></i></a></strong>
        </div>
        <div class="col-md-2">
            <a href="javascript:void(0);" onclick="base64('encode');" class="btn btn-outline-danger d-block mb-2">
                Encode<i class="fa fa-arrow-right ml-2"></i>
            </a>
            <a href="javascript:void(0);" onclick="base64('decode');" class="btn btn-outline-success d-block">
                Decode<i class="fa fa-arrow-left ml-2"></i>
            </a>
        </div>
        <div class="col-md-10">
            <textarea id="res1" cols="30" rows="3" class="form-control"></textarea>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-12 mb-2">
            <strong><u>Keygen Generate V1.1</u><a href="javascript:void(0);" onclick="kosong('res2');" class="btn btn-sm" title="Clear"><i class="fa fa-sync text-info"></i></a></strong>
        </div>
        <div class="col-md-2">
            <a href="javascript:void(0);" onclick="keygen('encode');" class="btn btn-outline-danger d-block mb-2">
                Encode<i class="fa fa-arrow-right ml-2"></i>
            </a>
            <a href="javascript:void(0);" onclick="keygen('decode');" class="btn btn-outline-success d-block">
                Decode<i class="fa fa-arrow-left ml-2"></i>
            </a>
        </div>
        <div class="col-md-10">
            <textarea id="res2" cols="30" rows="3" class="form-control"></textarea>
        </div>
    </div>
    <hr>
</div>
<!-- BODY END -->
<script>
    function kosong(id) {
        document.getElementById(id).value = '';
    }

    function generate(dt, id) {
        var val = document.getElementById(id).value;
        if (dt != 'api') {
            if (val == '') {
                toastr.error('Kolom ' + dt + ' Belum Di isi.');
                exit;
            }
        }
        $.post("<?= XROOT ?>init/generate/", {
            val,
            dt
        }, function(result) {
            if (result.success) {
                toastr.info('Generate Berhasil !')
                document.getElementById(id).value = result.data;
            } else {
                toastr.error(result.errorMsg);
            }
        }, 'json');
    }

    function base64(dt) {
        var val = document.getElementById("res1").value;
        if (val == '') {
            toastr.error('Kolom Base64 Belum Di isi.');
            exit;
        }
        if (dt == 'encode') {
            document.getElementById("res1").value = btoa(val);
        } else {
            document.getElementById("res1").value = atob(val);
        }
        toastr.info('Generate Berhasil !');
    }

    function keygen(dt) {
        var val = document.getElementById("res2").value;
        if (val == '') {
            toastr.error('Kolom Keygen Belum Di isi.');
            exit;
        }
        $.post("<?= XROOT ?>init/g_key/", {
            dt,
            val
        }, function(result) {
            if (result.success) {
                toastr.info('Generate Berhasil !')
                document.getElementById("res2").value = result.data;
            } else {
                toastr.error(result.errorMsg);
            }
        }, 'json');
    }
</script>