<style>
    .wid-t {
        border-bottom: 2px #000;
        top: 0rem;
        position: sticky;
        height: 50px;
        z-index: 1000
    }

    .header_top {
        background: none repeat scroll 0 0 <?= color('primary-a') ?>;
        color: <?= color('primary-b') ?>;
    }

    .social-icons ul li a {
        border: 0 none;
        border-radius: 0;
        color: <?= color('primary-b') ?>;
        padding: 0px;
    }

    .contactinfo ul li a {
        font-size: 12px;
        color: <?= color('primary-b') ?>;
        font-family: 'Roboto', sans-serif;
    }

    .footer-bottom {
        background: <?= color('primary-a') ?>;
        padding-top: 10px;
    }

    .footer-bottom p {
        color: <?= color('primary-b') ?>;
        font-family: 'Roboto', sans-serif;
        font-weight: 300;
        margin-left: 15px;
    }

    .response-area .media .pull-left {
        margin-right: 25px
    }

    .maintext {
        margin-top: 0px;
    }

    .maintext h2 {
        color: <?= color('secondary-b') ?>;
        font-family: abel;
        font-size: 27px;
        text-transform: uppercase;
    }

    .maintext h2 span {
        color: <?= color('secondary-a') ?>;
    }

    .maintext p {
        color: <?= color('secondary-b') ?>;
        font-family: 'Roboto', sans-serif;
        font-size: 12px;
        font-weight: 300;
    }

    .companyinfo {
        margin-top: 57px;
    }

    .companyinfo h2 {
        color: <?= color('secondary-b') ?>;
        font-family: abel;
        font-size: 27px;
        text-transform: uppercase;
    }

    .companyinfo h2 span {
        color: <?= color('secondary-a') ?>;
    }

    .companyinfo p {
        color: <?= color('secondary-b') ?>;
        font-family: 'Roboto', sans-serif;
        font-size: 12px;
        font-weight: 300;
    }

    .productinfo h2 {
        color: <?= color('secondary-a') ?>;
        font-family: 'Roboto', sans-serif;
        font-size: 24px;
        font-weight: 700;
    }

    .product-overlay h2 {
        color: #fff;
        font-family: 'Roboto', sans-serif;
        font-size: 24px;
        font-weight: 700;
    }


    .productinfo p {
        font-family: 'Roboto', sans-serif;
        font-size: 14px;
        font-weight: 400;
        color: <?= color('secondary-b') ?>;
    }

    .productinfo img {
        width: 100%;
    }

    .productinfo {
        position: relative;
    }

    .product-overlay {
        background: <?= color('secondary-a') ?>;
        top: 0;
        display: none;
        height: 0;
        position: absolute;
        transition: height 500ms ease 0s;
        width: 100%;
        display: block;
        opacity: 0.5;
    }

    .add-to-cart:hover {
        background: <?= color('secondary-a') ?>;
        border: 0 none;
        border-radius: 0;
        color: <?= color('secondary-c') ?>;
    }

    h2.title {
        color: <?= color('secondary-a') ?>;
        font-family: 'Roboto', sans-serif;
        font-size: 18px;
        font-weight: 700;
        margin: 0 15px;
        text-transform: uppercase;
        margin-bottom: 30px;
        position: relative;
    }

    .carousel-indicators li.active {
        background: <?= color('secondary-a') ?>;
    }

    .control-carousel:hover {
        color: <?= color('secondary-a') ?>;
    }

    .recommended-item-control i {
        background: none repeat scroll 0 0 <?= color('secondary-a') ?>;
        color: <?= color('secondary-c') ?>;
        font-size: 20px;
        padding: 4px 10px;
    }

    .recommended-item-control i:hover {
        background: #ccccc6;
    }

    .tooltip.top .tooltip-arrow {
        border-top-color: <?= color('secondary-a') ?>;
        border-width: 5px 5px 0;
        bottom: 0;
        left: 50%;
        margin-left: -5px;
    }

    a#scrollUp {
        bottom: 0px;
        right: 10px;
        padding: 5px 10px;
        background: <?= color('secondary-a') ?>;
        color: <?= color('secondary-c') ?>;
        -webkit-animation: bounce 2s ease infinite;
        animation: bounce 2s ease infinite;
    }

    a#scrollUp i {
        font-size: 30px;
    }

    @media (min-width: 601px) {
        .item {
            margin-right: 80px;
            min-height: 420px;
            margin-top: 20px;
        }
    }

    @media (max-width: 600px) {
        .item {
            margin-top: 220px;
            min-height: 400px;
        }
    }

    .item h1 span {
        color: <?= color('secondary-a') ?>;
    }

    .item button {
        color: <?= color('secondary-c') ?>;
        background: <?= color('secondary-a') ?>;
    }

    .item button:hover {
        color: <?= color('primary-b') ?>;
        background: <?= color('primary-a') ?>;
    }

    .img_c {
        display: flex;
        justify-content: center;
    }

    /* common */
    .ribbon {
        width: 100px;
        height: 100px;
        overflow: hidden;
        position: absolute;
    }

    .ribbon::before,
    .ribbon::after {
        position: absolute;
        z-index: -1;
        content: '';
        display: block;
        border: 5px solid #2980b9;
    }

    .ribbon span {
        position: absolute;
        display: block;
        width: 110px;
        padding: 4px 0;
        box-shadow: 0 5px 10px rgba(0, 0, 0, .1);
        color: #fff;
        /* font: 700 18px/1 'Lato', sans-serif; */
        text-shadow: 0 1px 1px rgba(0, 0, 0, .2);
        text-transform: uppercase;
        text-align: center;
    }

    /* top left*/
    .ribbon-top-left {
        top: -10px;
        left: -10px;
    }

    .ribbon-top-left::before,
    .ribbon-top-left::after {
        border-top-color: transparent;
        border-left-color: transparent;
    }

    .ribbon-top-left::before {
        top: 0;
        right: 0;
    }

    .ribbon-top-left::after {
        bottom: 0;
        left: 0;
    }

    .ribbon-top-left span {
        right: -25px;
        top: 30px;
        transform: rotate(-45deg);
    }

    /* top right*/
    .ribbon-top-right {
        top: -10px;
        right: -10px;
    }

    .ribbon-top-right::before,
    .ribbon-top-right::after {
        border-top-color: transparent;
        border-right-color: transparent;
    }

    .ribbon-top-right::before {
        top: 0;
        left: 0;
    }

    .ribbon-top-right::after {
        bottom: 0;
        right: 0;
    }

    .ribbon-top-right span {
        left: -25px;
        top: 30px;
        transform: rotate(45deg);
    }

    /* bottom left*/
    .ribbon-bottom-left {
        bottom: -10px;
        left: -10px;
    }

    .ribbon-bottom-left::before,
    .ribbon-bottom-left::after {
        border-bottom-color: transparent;
        border-left-color: transparent;
    }

    .ribbon-bottom-left::before {
        bottom: 0;
        right: 0;
    }

    .ribbon-bottom-left::after {
        top: 0;
        left: 0;
    }

    .ribbon-bottom-left span {
        right: -25px;
        bottom: 30px;
        transform: rotate(225deg);
    }

    /* bottom right*/
    .ribbon-bottom-right {
        bottom: -10px;
        right: -10px;
    }

    .ribbon-bottom-right::before,
    .ribbon-bottom-right::after {
        border-bottom-color: transparent;
        border-right-color: transparent;
    }

    .ribbon-bottom-right::before {
        bottom: 0;
        left: 0;
    }

    .ribbon-bottom-right::after {
        top: 0;
        right: 0;
    }

    .ribbon-bottom-right span {
        left: -25px;
        bottom: 30px;
        transform: rotate(-225deg);
    }

    carousel-inner .item img {
        display: inline-block;
        margin-left: 15px;
        margin-top: 30px;
    }
</style>