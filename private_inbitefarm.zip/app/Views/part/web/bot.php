<footer id="footer">
    <!--Footer-->
    <?php
    $l1 =  substr(inc('app-name'), 0, 1);
    $l2 =  str_replace($l1, "", inc('app-name'));
    ?>
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-sm-2">
                    <div class="companyinfo">
                        <h2><strong><span><?= $l1 ?></span><?= $l2 ?></strong></h2>
                        <p><?= inc('app-name-2') ?></p>
                    </div>
                </div>

                <div class="col-sm-7">

                    <!-- <div class="col-sm-3">
                        <div class="video-gallery text-center">
                            <a href="#">
                                <div class="iframe-img">
                                    <img src="<?= XROOT ?>script/web2/images/home/iframe1.png" alt="" />
                                </div>
                                <div class="overlay-icon">
                                    <i class="fa fa-play-circle-o"></i>
                                </div>
                            </a>
                            <p>Circle of Hands</p>
                            <h2>24 DEC 2014</h2>
                        </div>
                    </div> -->

                </div>
                <div class="col-sm-3">
                    <div class="address">
                        <img src="<?= XROOT ?>script/web2/images/home/map.png" alt="" />
                        <p><strong>Alamat : </strong> <?= inc('alamat') ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <p class="pull-left">Copyright © <?= date("Y") . ' ' . inc('nama-instansi') ?> . All rights reserved.</p>
                <p class="pull-right">Tanggal : <span><?= date("d") . ' ' . bn(date("m")) . ' ' . date("Y") ?></span></p>
            </div>
        </div>
    </div>

</footer>
<!--/Footer-->



<script src="<?= XROOT ?>script/web2/js/jquery.js"></script>
<script src="<?= XROOT ?>script/web2/js/bootstrap.min.js"></script>
<script src="<?= XROOT ?>script/web2/js/jquery.scrollUp.min.js"></script>
<script src="<?= XROOT ?>script/web2/js/price-range.js"></script>
<script src="<?= XROOT ?>script/web2/js/jquery.prettyPhoto.js"></script>
<script src="<?= XROOT ?>script/web2/js/main.js"></script>
</body>

</html>