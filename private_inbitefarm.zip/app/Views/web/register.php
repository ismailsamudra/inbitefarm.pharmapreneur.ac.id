<img class="wave" src="<?= XROOT ?>img/dev/<?= inc('wave-login') ?>">
<div class="container">
    <?php
    $cek = num_rows('engine', en64('level="' . inc('level_regist') . '"'));
    $oo = db('engine')->getWhere(['level' => inc('level_regist')])->getResult();
    ?>
    <div class="img">
        <div class="m-2">
            <?= inc('desk-login'); ?>
        </div>
    </div>
    <div class="login-content">
        <form id="fm">
            <div id="content"></div>
            <div id="bodi">
                <?php
                if ($cek < 2) {
                    echo '
                <img src="' . XROOT . 'img/instansi/' . inc('logo') . '">
                 <h5 class="title">' . inc('app-name') . '</h5>
                ';
                }
                ?>
                <strong class="pri-c">HALAMAN REGISTRASI</strong>
                <br>
                <br>
                <?php
                if ($cek > 1) {
                    echo '
                <i class="fab fa-weibo pri-c mr-2"></i> Pilih Akses
                   <div class="row">   
                ';
                    foreach ($oo as $o) {
                        echo '
                <div class="col-6">
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <input type="radio" name="akses" id="a' . $o->id . '" Value="' . $o->akses . '">
                            </span>
                        </div>
                        <input type="text" class="form-control" value="' . $o->akses_name . '" readonly>
                    </div>
                </div>
                ';
                    }
                    echo '
                   </div>
                ';
                }
                ?>

                <?php
                if ($cek == 0) {
                    echo '<br><br><br>
                <strong>
                    Maaf ! Level Registrasi Belum Di Set Oleh Admin.
                </strong><br><br><br>
                ';
                } else {
                    echo '
               <div class="input-group mb-2">
               <div class="input-group-prepend">
                   <span class="input-group-text"><i class="fas fa-user pri-c"></i></span>
               </div>
               <input type="text" class="form-control" id="nama" placeholder="Nama Lengkap Tanpa Title">
           </div>
           <div class="input-group mb-2">
               <div class="input-group-prepend">
                   <span class="input-group-text"><i class="fa fa-envelope pri-c"></i></span>
               </div>
               <input type="email" class="form-control" id="email" placeholder="Email">
           </div>
           <div class="input-group mb-2">
               <div class="input-group-prepend">
                   <span class="input-group-text"><i class="fab fa-whatsapp pri-c"></i></span>
               </div>
               <input type="text" class="form-control" id="hp" placeholder="No.Hp [ Whatsapp ]">
           </div>
           <i class="fa fa-venus-mars pri-c mr-2"></i> Jenis Kelamin
           <div class="row">
               <div class="col-6">
                   <div class="input-group mb-2">
                       <div class="input-group-prepend">
                           <span class="input-group-text">
                               <input type="radio" class="" name="jk" id="jk1" Value="L">
                           </span>
                       </div>
                       <input type="text" class="form-control" value="Laki-Laki" readonly>
                   </div>
               </div>
               <div class="col-6">
                   <div class="input-group mb-2">
                       <div class="input-group-prepend">
                           <span class="input-group-text">
                               <input type="radio" class="" name="jk" id="jk2" Value="P">
                           </span>
                       </div>
                       <input type="text" class="form-control" value="Perempuan" readonly>
                   </div>
               </div>
           </div>
               ';
                }
                ?>

                <br>
                <a href="<?= XROOT ?>login" class="float-left pri-c"><strong>Login</strong></a>
                <?php echo (inc('forgot') == 'true') ? '<a href="' . XROOT . 'forgot" class="float-right pri-c"><strong>Lupa Password?</strong></a>' : ''; ?>
                <br>
                <center>
                    <a href="javascript:void(0);" onclick="daftar()" class="btn">Daftar</a>
                </center>
                <?php echo (inc('web_status') == 'true') ? '<a href="' . XROOT . '"><strong>Website</strong></a>' : ''; ?>
                <strong>© <?= date("Y") . ' ' . inc('nama-instansi') ?> .All Rights Reserved.</strong>
            </div>
        </form>
    </div>

</div>
<?php
foreach ($oo as $o) {
    if ($cek == 1) {
        echo '<input type="hidden" name="akses" id="a' . $o->id . '" Value="' . $o->akses . '">';
    }
    if ($o->role == 'DEFAULT_AKSES') {
        echo '
        <script>
        document.getElementById("a' . $o->id . '").checked = true;
        </script>
        ';
    }
}
?>
<script>
    document.getElementById("jk1").checked = true;

    function daftar() {
        var cek = "<?= $cek ?>";
        if (cek == 1) {
            var akses = $("[name='akses']").val();
        } else {
            var akses = $("input[type='radio'][name='akses']:checked").val();
        }
        var nama = document.getElementById("nama").value;
        var email = document.getElementById("email").value;
        var hp = document.getElementById("hp").value;
        var jk = $("input[type='radio'][name='jk']:checked").val();
        (akses) ? '' : [toastr.error('Akses Belum dipilih.'), exit];
        (nama) ? '' : [toastr.error('Nama Belum Di isi.'), $('#nama').focus(), exit];
        (email) ? '' : [toastr.error('Email Belum Di isi.'), $('#email').focus(), exit];
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (!email.match(mailformat)) {
            toastr.error('Format Email Salah');
            $('#email').focus();
            exit;
        }
        (hp) ? '' : [toastr.error('No.Hp Belum Di isi.'), $('#hp').focus(), exit];
        (jk) ? '' : [toastr.error('Jenis Kelamin Belum dipilih.'), exit];
        $("#bodi").hide()
        $("#content").html(`
        <center>
            <img src="<?= XROOT ?>img/dev/loading.gif">
            <br>
            <br>
            <small><strong>Harap Menunggu...</strong></small>
        </center>
        `);
        $.post("<?= XROOT ?>portal/regist", {
            akses,
            nama,
            email,
            hp,
            jk
        }, function(result) {
            if (result.success) {
                $('#bodi').hide();
                $('#content').html(`
                <h3>Registrasi Berhasil !</h3><br>
                Password telah dikirim <br> ke Email atau No. Whatsapp yang anda Daftarkan
                <br>
                <br>
                <strong>
                        Nama : ` + nama + `<br>
                        Email : ` + email + `<br>
                        No.Hp [ Whatsapp ] : ` + hp + `<br>
                </strong>
                <br>
                <a href="<?= XROOT ?>login" class="btn-sm btn-dark bg-1-h">Login</a>
                `);
            } else {
                $("#bodi").show()
                $("#content").html('');
                toastr.error(result.errorMsg);
            }
        }, 'json');
    }
    $('#hp').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
</script>