<img class="wave" src="<?= XROOT ?>img/dev/<?= inc('wave-login') ?>">
<div class="container">

    <div class="img">
        <div class="m-2">
            <?= inc('desk-login'); ?>
        </div>
    </div>
    <div class="login-content">
        <form>
            <div id="content"></div>
            <div id="bodi">
                <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>">
                <h4 class="title"><?= inc('app-name') ?></h4>

                <br>
                <div class="input-div one">
                    <div class="i">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="div">
                        <h5>Email / No.Hp [Wa]</h5>
                        <input type="text" class="input" name="userid" id="userid">
                    </div>
                </div>
                <div class="input-div pass">
                    <div class="i">
                        <i class="fas fa-lock"></i>
                    </div>
                    <div class="div">
                        <h5>Password</h5>
                        <input type="password" class="input" name="password" id="password">
                    </div>
                </div>
                <br>
                <?php echo (inc('register') == 'true') ? '<a href="' . XROOT . 'register" class="float-left pri-c"><strong>Registrasi</strong></a>' : ''; ?>
                <?php echo (inc('forgot') == 'true') ? '<a href="' . XROOT . 'forgot" class="float-right pri-c"><strong>Lupa Password?</strong></a>' : ''; ?>
                <br>
                <center>
                    <a href="javascript:void(0);" onclick="login()" class="btn">Login</a>
                </center>
                <?php echo (inc('web_status') == 'true') ? '<a href="' . XROOT . '"><strong>Website</strong></a>' : ''; ?>
                <strong>© <?= date("Y") . ' ' . inc('nama-instansi') ?> .All Rights Reserved.</strong>
            </div>
        </form>
    </div>

</div>
<script>
    function login() {
        var username = document.getElementById("userid").value;
        var password = document.getElementById("password").value;
        if (username == '') {
            toastr.error('Username Belum Di isi.');
            exit;
        }
        if (password == '') {
            toastr.error('Password Belum Di isi.');
            exit;
        }
        $("#bodi").hide()
        $("#content").html(`
        <center>
            <img src="<?= XROOT ?>img/dev/loading.gif">
            <br>
            <br>
            <small><strong>Harap Menunggu...</strong></small>
        </center>
        `);
        $.post("<?= XROOT ?>portal/login", {
            username,
            password
        }, function(result) {
            if (result.success) {
                toastr.info('Login Berhasil harap Menunggu.')
                window.location.reload();
            } else {
                $("#bodi").show()
                $("#content").html('');
                toastr.error(result.errorMsg);
            }
        }, 'json');
    }
</script>