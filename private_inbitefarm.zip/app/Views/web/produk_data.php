<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?= $title ?></title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link href="<?= XROOT ?>script/web2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/price-range.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/animate.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/main.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= XROOT ?>script/toastr/toastr.min.css">
    <?php
    echo view('part/web/css');
    $o = db('produk_data')->getWhere(['id' => $id])->getRow();
    ?>
</head>
<!--/head-->

<body>
    <!-- BODY START -->
    <br>
    <br>
    <div class="container">
        <a href="javascript:void(0);" onclick="history.back()" style="float:right;margin: left 10px;" class="float-right ml-2"><i class="fa fa-times fa-3x"></i></a>
        <div class="row">
            <div class="col-sm-5">
                <center>
                    <?php
                    if ($o->aksi == 'Semai') {
                        $warna = '#0066FF';
                    } elseif ($o->aksi == 'Ready') {
                        $warna = '#38761d';
                    } else {
                        $warna = '#f44336';
                    }
                    if ($o->aksi != 'null') {
                        echo '<div class="ribbon ribbon-top-right">
                        <span style="background-color:' . $warna . ';">' . $o->aksi . '</span>
                        </div>';
                    }
                    ?>
                    <img src="<?= XROOT ?>img/web/produk/<?= $o->img ?>" alt="" width="100%" />
                </center>
            </div>
            <div class="col-sm-7">
                <?php
                if ($o->aksi != 'Semai') {
                    echo '<a href="javascript:void(0);" onclick="add();" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Pesan Sekarang</a>';
                }
                if ($o->new == 'Y') {
                    echo '<div class="badge"><strong>NEW</strong></div>';
                }
                ?>
                <h2 class="title">~ <?= $o->nama ?> ~</h2>
                <h4><strong>Tanggal Ready : <?= date("d/m/Y", strtotime($o->tgl_ready)) ?> </strong></h4>
                <h4><strong>Stok : <?= $o->qty . ' ' . $o->satuan ?> </strong></h4>
                <h4><strong>Minimal Order : <?= $o->min_order . ' ' . $o->satuan ?> </strong></h4>
                <h2><small><strong><?= "IDR " . number_format($o->harga, 0, ',', '.') ?> </strong>/ <?= $o->satuan ?></small></h2>
                <?= $o->desk ?>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <!-- BODY END -->
    <!-- Start Modal 1 -->
    <div class="modal fade" id="order" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fa fa-shopping-cart mr-2"></i> Order <strong> <?= $o->nama ?></strong></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form id="fm" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" id="id">
                        <label for=""><small>Nama [ Wajib ]</small></label>
                        <input type="text" name="nama" id="nama" class="form-control">
                        <label for=""><small>No HP / WA [ Wajib ]</small></label>
                        <input type="text" name="hp" id="hp" class="form-control">
                        <label for=""><small>Email [ Optional ]</small></label>
                        <input type="text" name="email" id="email" class="form-control">
                        <label for=""><small>Alamat [ Wajib ]</small></label>
                        <textarea name="alamat" id="alamat" cols="30" rows="2" class="form-control"></textarea>
                        <label for=""><small>Kerangan [ Optional ]</small></label>
                        <textarea name="ket" id="ket" cols="30" rows="2" class="form-control"></textarea>
                        <label for=""><small>Jumblah Order [ Wajib ]</small></label>
                        <div class="text-danger">
                            <strong>NB:</strong><br>
                            <small>* Harga Per <?= $o->satuan ?> : <?= "IDR. " . number_format($o->harga, 0, ',', '.'); ?></small><br>
                            <small>* Tersisa <?= $o->qty . ' ' . $o->satuan ?></small><br>
                            <small>* Minimum Order <?= $o->min_order . ' ' . $o->satuan ?></small>
                        </div>
                        <label for=""><small>Total Bayar [ IDR. <span id="lb_harga">0</span> ]</small></label>
                        <input type="text" name="order_qty" id="order_qty" onkeyup="lb_harga();" placeholder="Number Only" class="form-control">

                    </form>

                </div>
                <div class="modal-footer">
                    <a href="javascript:void(0);" onclick="pesan();" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i> Order</a>
                </div>

            </div>
        </div>
    </div>
    <!-- End Modal 1-->
</body>
<script src="<?= XROOT ?>script/web2/js/jquery.js"></script>
<script src="<?= XROOT ?>script/web2/js/bootstrap.min.js"></script>
<script src="<?= XROOT ?>script/web2/js/jquery.scrollUp.min.js"></script>
<script src="<?= XROOT ?>script/web2/js/price-range.js"></script>
<script src="<?= XROOT ?>script/web2/js/jquery.prettyPhoto.js"></script>
<script src="<?= XROOT ?>script/toastr/toastr.min.js"></script>
<!-- <script src="<?= XROOT ?>script/web2/js/main.js"></script> -->
</body>
<script>
    //-----------------------------------------start
    function add() {
        var sisa = '<?= $o->qty ?>';
        if (sisa < 1) {
            toastr.error('Maaf !! Stok Sudah Habis.');
            exit;
        } else {
            $('#order').modal('show');
        }

    }
    //-----------------------------------------end
    $('#hp').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
    $('#order_qty').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
    //-----------------------------------------start
    function pesan() {
        var nama = document.getElementById("nama").value;
        if (nama == '') {
            toastr.error('Nama Anda Harus Di isi');
            exit;
        }
        var hp = document.getElementById("hp").value;
        if (hp == '') {
            toastr.error('No Hp / WA Harus Di isi');
            exit;
        }
        var alamat = document.getElementById("alamat").value;
        if (alamat == '') {
            toastr.error('Alamat Harus Di isi');
            exit;
        }
        let order_qty = document.getElementById("order_qty").value;
        if (order_qty == '') {
            toastr.error('Jumblah Order Harus Di isi');
            exit;
        }
        let min_order = parseInt('<?= $o->min_order ?>');
        if (order_qty < min_order) {
            toastr.error('Jumblah Order Tidak boleh dibawah <br> <?= $o->min_order . ' ' . $o->satuan ?>');
            exit;
        }
        var email = document.getElementById("email").value;
        var ket = document.getElementById("ket").value;
        $.ajax({
            url: '<?= XROOT ?>produk/save_order',
            method: 'POST',
            data: {
                nama,
                hp,
                email,
                alamat,
                order_qty,
                ket,
                produk_id: '<?= $o->id ?>'
            },
            cache: false,
            success: function(data) {
                if (data == 200) {
                    toastr.info('Terimakasih ! PerMintaan Anda Berhasil Di kirim <br> harap menunggu konfirmasi admin lewat Email atau whatsapp');
                    $('#order').modal('hide');
                } else {
                    toastr.error(data);
                }

            }
        });

    }
    //-----------------------------------------end
    //-----------------------------------------start
    function lb_harga() {
        let qty = document.getElementById("order_qty").value;
        let harga = '<?= $o->harga ?>';
        let total = eval(harga + '*' + qty);
        let number_string = total.toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        qty = null ? '0' : qty;
        if (qty < 1) {
            document.getElementById("lb_harga").innerHTML = '0';
        } else {
            document.getElementById("lb_harga").innerHTML = rupiah;

        }
    }
    //-----------------------------------------end
</script>

</html>
<!-- Modal -->
<div id="selengkapnya" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Modal Header</h4>
            </div>
            <div class="modal-body">
                <p>Some text in the modal.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>