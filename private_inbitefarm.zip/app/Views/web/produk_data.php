<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?= $title ?></title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link href="<?= XROOT ?>script/web2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/price-range.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/animate.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/main.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/responsive.css" rel="stylesheet">
    <?php
    echo view('part/web/css');
    $o = db('produk_data')->getWhere(['id' => $id])->getRow();
    ?>
</head>
<!--/head-->

<body>
    <!-- BODY START -->
    <br>
    <br>
    <div class="container">
        <a href="javascript:void(0);" onclick="history.back()" style="float:right;margin: left 10px;" class="float-right ml-2"><i class="fa fa-times fa-3x"></i></a>
        <div class="row">
            <div class="col-sm-5">
                <center>
                    <?php
                    if ($o->new == 'Y' && $o->habis == 'T') {
                        echo '<div class="ribbon ribbon-top-right">
                                    <span style="background-color:#0066FF;">BARU</span>
                                </div>';
                    }
                    if ($o->habis == 'Y') {
                        echo '<div class="ribbon ribbon-top-right">
                                    <span style="background-color:#ff0026;">HABIS</span>
                                </div>';
                    }
                    ?>
                    <img src="<?= XROOT ?>img/web/produk/<?= $o->img ?>" alt="" width="100%" />
                </center>
            </div>
            <div class="col-sm-7">
                <h2 class="title">~ <?= $o->nama ?> ~</h2>
                <h2><small><strong><?= "IDR " . number_format($o->harga, 0, ',', '.') ?> </strong> <?= $o->satuan ?></small></h2>
                <?= $o->desk ?>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <!-- BODY END -->
</body>
<script src="<?= XROOT ?>script/web2/js/jquery.js"></script>
<script src="<?= XROOT ?>script/web2/js/bootstrap.min.js"></script>
<script src="<?= XROOT ?>script/web2/js/jquery.scrollUp.min.js"></script>
<script src="<?= XROOT ?>script/web2/js/price-range.js"></script>
<script src="<?= XROOT ?>script/web2/js/jquery.prettyPhoto.js"></script>
<!-- <script src="<?= XROOT ?>script/web2/js/main.js"></script> -->
</body>

</html>
<!-- Modal -->
<div id="selengkapnya" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Modal Header</h4>
            </div>
            <div class="modal-body">
                <p>Some text in the modal.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>