<style>
    h6 {
        font-size: 3rem;
        font-family: 'bamboo', cursive;
    }
</style>
<section id="slider_produk" class="slider_produk">
    <div class="slider_overlay">
        <div class="container">
            <div class="row">
                <div class="text-center">
                    <div class="col-md-12">
                        <div class="main_slider_content wow zoomIn" data-wow-duration="1s">
                            <h6 style="color:<?= inc('web_produk_text_color') ?>;"><?= inc('web_produk_label') ?></h6>
                            <!-- <button href="" class="btn-lg">Click here</button> -->
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $kt = db('produk_kategori')->orderBy('id', 'ASC')->getWhere(['status' => 'true'])->getResult(); ?>
<?php foreach ($kt as $o) : ?>
    <section id="portfolio" class="portfolio">
        <div class="container">
            <div class="row">

                <div id="<?= $o->id ?>" class="col-md-12">
                    <div class="head_title text-center">
                        <h4>~ <?= $o->nama ?> ~</h4>
                        <h5 style="color: black;"> <?= $o->ket ?> </h5>
                    </div>
                </div>
                <?php $dt = db('produk_data')->orderBy('id', 'DESC')->getWhere(['status' => 'true', 'kategori' => $o->id])->getResult(); ?>
                <?php foreach ($dt as $x) : ?>
                    <div class="col-md-3 mrg">
                        <a href="<?= $x->url ?>">
                            <center>
                                <?php
                                if ($x->new == 'Y') {
                                    echo '<div class="ribbon ribbon-top-right">
                                    <span>NEW</span>
                                </div>';
                                }
                                ?>
                                <img src="<?= XROOT ?>img/web/produk/<?= $x->img ?>" alt="" />
                            </center>
                            <h7>
                                <center><?= $x->nama ?></center>
                            </h7>
                        </a>
                    </div>
                <?php endforeach ?>

            </div>
        </div>
        </div>
        </div>
    </section>
<?php endforeach ?>