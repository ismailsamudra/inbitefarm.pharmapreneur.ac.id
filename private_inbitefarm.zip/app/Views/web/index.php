<?php
$hid = ($id == null) ? '' : 'hidden';
?>
<section id="slider">
    <?php
    $l1 =  substr(inc('app-name'), 0, 1);
    $l2 =  str_replace($l1, "", inc('app-name'));
    ?>
    <!--slider-->
    <div class="container">
        <div class="row" <?= $hid ?>>
            <div class="col-sm-12">
                <div id="slider-carousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
                        <li data-target="#slider-carousel" data-slide-to="1"></li>
                        <li data-target="#slider-carousel" data-slide-to="2"></li>
                    </ol>

                    <div class="carousel-inner">
                        <?php $gl = db('web_gallery')->orderBy('id', 'RANDOM')->getWhere(['status' => 'true'])->getResult(); ?>
                        <?php foreach ($gl as $g) : ?>
                            <div class="item <?= $g->sync ?>">
                                <style>
                                    .actf<?= $g->id ?> {
                                        background: url(<?= XROOT . 'img/web/gallery/' . $g->img ?>) center center no-repeat;
                                        background-size: cover;
                                        min-height: 400px;
                                    }
                                </style>
                                <div class="actf<?= $g->id ?>">
                                </div>
                            </div>
                        <?php endforeach ?>
                    </div>

                    <a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
                        <i class="fa fa-angle-left"></i>
                    </a>
                    <a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>

            </div>
        </div>
    </div>
</section>
<!--/slider-->

<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="left-sidebar">
                    <h2 class="title">Category</h2>
                    <div class="panel-group category-products" id="accordian">
                        <!--category-productsr-->
                        <div class="search_box">
                            <input type="text" id="cari" onkeyup="cari()" placeholder="Search" />
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title sidetext"><a href="javacript:void(0);" onclick="myproduk()">Produk Kami</a></h4>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title sidetext"><a href="javacript:void(0);" onclick="p_unggul()">Produk Unggul</a></h4>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title sidetext"><a href="javacript:void(0);" onclick="p_baru()">Produk Baru</a></h4>
                            </div>
                        </div>
                        <?php $kt = db('produk_kategori')->getWhere(['status' => 'true'])->getResult(); ?>
                        <?php foreach ($kt as $p) : ?>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title sidetext"><a href="javacript:void(0);" onclick="kategori('<?= $p->id ?>','<?= $p->nama ?>')"><?= $p->nama ?></a></h4>
                                </div>
                            </div>
                        <?php endforeach ?>
                    </div>
                    <!--/category-products-->

                </div>
            </div>

            <div class="col-sm-9 padding-right">
                <h2 class="title text-center" id="main_lb">PRODUK KAMI</h2>
                <?php
                $url =  ($id == null) ? XROOT . 'web/main' : XROOT . 'web/selengkapnya/' . $id;
                ?>
                <script>
                    function resizeIframe(obj) {
                        obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
                    }

                    function cari() {
                        var cari = document.getElementById('cari').value;
                        if (cari == '') {
                            document.getElementById('main_lb').innerHTML = '<h2 class="title text-center">PRODUK KAMI</h2>';
                            document.getElementById('frame').src = '<?= XROOT ?>web/main';
                        } else {
                            document.getElementById('main_lb').innerHTML = '<h2 class="title text-center">HASIL PENCARIAN</h2>';
                            document.getElementById('frame').src = '<?= XROOT ?>web/main/' + cari;
                        }
                    }

                    function myproduk() {
                        document.getElementById('main_lb').innerHTML = '<h2 class="title text-center">PRODUK KAMI</h2>';
                        document.getElementById('frame').src = '<?= XROOT ?>web/main';
                    }

                    function kategori(id, nama) {
                        document.getElementById('main_lb').innerHTML = '<h2 class="title text-center">' + nama + '</h2>';
                        document.getElementById('frame').src = '<?= XROOT ?>web/main/kategori/' + id;
                    }

                    function p_unggul() {
                        document.getElementById('main_lb').innerHTML = '<h2 class="title text-center">PRODUK UNGGUL</h2>';
                        document.getElementById('frame').src = '<?= XROOT ?>web/main/kategori/xxunggulxx';
                    }

                    function p_baru() {
                        document.getElementById('main_lb').innerHTML = '<h2 class="title text-center">PRODUK BARU</h2>';
                        document.getElementById('frame').src = '<?= XROOT ?>web/main/kategori/xxbaruxx';
                    }
                </script>
                <iframe id="frame" src="<?= $url ?>" width="100%" scrolling="no" onload="resizeIframe(this)" frameborder="0"></iframe>


            </div>

        </div>
    </div>
</section>
<style>
    .widget-whatsapp {
        position: fixed;
        bottom: 90px;
        right: 50px;
        font-size: 40px;
        -webkit-border-radius: 999px;
        -moz-border-radius: 999px;
        border-radius: 999px;
        width: 60px;
        height: 60px;
        text-align: center;
        z-index: 1999;

    }
</style>
<?php
if (inc('url_whatsapp') != null) {
    echo '<div class="widget-whatsapp">
    <a target="_blank" class="text-white" href="' . inc('url_whatsapp') . '">
        <img src="' . XROOT . 'img/dev/wa.gif" style="margin: left 10px;" alt="" width="80" title="Whatsapp Kami" />

    </a>
</div>';
}
?>