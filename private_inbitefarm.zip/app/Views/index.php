<?php index('main'); ?>
<aside class="main-sidebar sidebar-light-costume elevation-2">
    <a href="" class="brand-link">
        <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light"> <strong><?= inc('app-name') ?></strong> </span>
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 d-flex">
            <div class="image">
                <?php $ft = (me('foto') == null) ? me('jk') . '2.png' : me('foto'); ?>
                <img src="<?= (me() == '28071986') ? me('foto') : XROOT . 'img/avatar/' . $ft ?>" class="img-rounded elevation-3" alt="<?= me('nama') ?>" title="<?= me('nama') ?>">
            </div>
            <div class="info font-weight-bold" title="<?= me('nama') ?>">
                <?= me('nama') ?>
            </div>
        </div>
        <?php
        // if (me() == '1' || me() == '28071986') {
        //     echo '<small class="ml-4" style="color:' . color('primary-a') . ';">License : <strong>' . inc('sertificate_expire') . '</strong></small>';
        // } else {
        echo '<small class="ml-4" style="color:' . color('primary-a') . ';">Level : <strong>' . level_n(me("level")) . '</strong></small>';
        // }
        ?>
        <!--================================== SLIDEBAR START ========================-->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <?php
                if (me() != '28071986' && me() != '1') {
                    echo '    
                        <li class="nav-item">
                        <a href="users/biodata" class="nav-link">
                        <i class="nav-icon fa fa-id-card"></i>
                        <p>
                        BIODATA SAYA
                        </p>
                        </a>
                        </li> ';
                }
                ?>
                <!--========== SIDEBAR DB START ==========-->
                <?php
                $ck_level = num_rows('engine', en64('level="' . me('level') . '"'));
                $ck_akses = num_rows('engine', en64('akses="' . me('akses') . '"'));
                if (me() != '28071986') {
                    ($ck_level > 0) ?: go('logout');
                    if ($ck_akses == 0) {
                        update('users', ['akses' => akses_d(me('level'))], ['id' => me()]);
                    }
                }
                if ($ck_akses > 0) {
                    $side1 = db('temp_sidebar')->orderBy('col1', 'ASC')->getWhere(['status' => 'true', me('akses') => '1', 'colum' => '1'])->getResult();
                    foreach ($side1 as $a) {
                        if ($a->role == '1') {
                            echo '
                    <li class="nav-item">
                    <a href="' . $a->url . '" class="nav-link">
                    <i class="nav-icon ' . $a->icon . '"></i>
                    <p>
                    ' . $a->nama . '
                    </p>
                    </a>
                    </li> 
                    ';
                        } else {
                            echo '
                    <li class="nav-item">
                    <a href="#" class="nav-link">
                    <i class="nav-icon ' . $a->icon . '"></i>
                    <p>
                    ' . $a->nama . '
                    <i class="fas fa-angle-left right"></i>
                    </p>
                    </a>
                    <ul class="nav nav-treeview">  
                    ';
                            $side2 = db('temp_sidebar')->orderBy('col2', 'ASC')->getWhere(['status' => 'true', me('akses') => '1', 'colum' => '2', 'group_1' => $a->id])->getResult();
                            foreach ($side2 as $b) {
                                if ($b->role == '1') {
                                    echo '
                            <li class="nav-item">
                            <a href="' . $b->url . '" class="nav-link">
                           <i class="nav-icon ' . $b->icon . '"></i>
                            <p>
                            ' . $b->nama . '
                            </p>
                            </a>
                            </li> 
                            ';
                                } else {
                                    echo '
                            <li class="nav-item ">
                            <a href="#" class="nav-link">
                            <i class="nav-icon ' . $b->icon . '"></i>
                            <p>
                            ' . $b->nama . '
                            <i class="fas fa-angle-left right"></i>
                            </p>
                            </a>
                            <ul class="nav nav-treeview">  
                            ';
                                    $side3 = db('temp_sidebar')->orderBy('col3', 'ASC')->getWhere(['status' => 'true', me('akses') => '1', 'colum' => '3', 'group_1' => $b->id])->getResult();
                                    foreach ($side3 as $c) {
                                        if ($c->id == inc('side_h1') && me('jk') == 'L') {
                                            echo '';
                                        } else {
                                            echo '
                                            <li class="nav-item">
                                            <a href="' . $c->url . '" class="nav-link">
                                            <i class="nav-icon ' . $c->icon . '"></i>
                                            <p>
                                            ' . $c->nama . '
                                            </p>
                                            </a>
                                            </li> 
                                            ';
                                        }
                                    }
                                    echo '</ul></li>';
                                }
                            }
                            echo '</ul></li>';
                        }
                    }
                }

                ?>
                <!--========== SIDEBAR DB END ==========-->
                <?php
                if (me() == '28071986' || me() == '1') {
                    echo '
                            <!--========== SIDEBAR ADMIN START ==========-->
                            <li class="nav-item ">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fab fa-staylinked"></i>
                                    <p>
                                        MENU SISTEM
                                        <i class="fas fa-angle-left right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">

                                <li class="nav-item">
                                    <a href="inc/m_book" class="nav-link">
                                        <i class="nav-icon fa fa-book"></i>
                                        <p>
                                            EDIT M-BOOK
                                        </p>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="inc/control" class="nav-link">
                                        <i class="nav-icon fab fa-whmcs"></i>
                                        <p>
                                            CONTROL SETTING
                                        </p>
                                    </a>
                                </li>

                                    <li class="nav-item">
                                        <a href="inc/apps" class="nav-link">
                                            <i class="nav-icon fab fa-joget"></i>
                                            <p>
                                                SETTING APPS
                                            </p>
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="inc/android" class="nav-link">
                                            <i class="nav-icon fab fa-android"></i>
                                            <p>
                                                DATA ANDROID
                                            </p>
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="inc/color" class="nav-link">
                                            <i class="nav-icon fa fa-paint-brush"></i>
                                            <p>
                                                UBAH WARNA
                                            </p>
                                        </a>
                                    </li>
                  
                                    <li class="nav-item">
                                        <a href="inc/smtp_email" class="nav-link">
                                            <i class="nav-icon far fa-envelope"></i>
                                            <p>
                                                SMTP EMAIL
                                            </p>
                                        </a>
                                    </li>
                    
                                </ul>
                            </li>
                            <!--========== SIDEBAR ADMIN END ==========-->
                            ';
                }
                ?>
                <?php
                if (me() == '28071986') {
                    echo '
                            <!--========== SIDEBAR ADMIN START ==========-->
                            <li class="nav-item ">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fab fa-resolving"></i>
                                    <p>
                                        MENU DEVELOPMENT
                                        <i class="fas fa-angle-left right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">

                                    <li class="nav-item">
                                        <a href="init/engine" class="nav-link">
                                            <i class="nav-icon fab fa-react"></i>
                                            <p>
                                                USER ENGINE
                                            </p>
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="init/sidebar" class="nav-link">
                                            <i class="nav-icon fa fa-th-list"></i>
                                            <p>
                                                SIDEBAR
                                            </p>
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="init/keygen" class="nav-link">
                                            <i class="nav-icon fa fa-key"></i>
                                            <p>
                                                KEYGEN
                                            </p>
                                        </a>
                                    </li>

                                </ul>
                            </li>
                            <!--========== SIDEBAR ADMIN END ==========-->
               ';
                }
                ?>
                <li class="nav-item">
                    <a href="users/m_book" class="nav-link">
                        <i class="nav-icon fa fa-book"></i>
                        <p>
                            MANUAL BOOK
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!--================================== SLIDEBAR END ==========================-->
    </div>
</aside>
<!-- Start Content-->

<div class="content-wrapper iframe-mode" data-widget="iframe" data-loading-screen="750">
    <div class="nav navbar navbar-expand navbar-white navbar-light border-bottom p-0">

        <ul class="navbar-nav overflow-hidden" role="tablist"></ul>
        <a class="nav-link bg-light" href="#" data-widget="iframe-fullscreen"><i class="fas fa-expand"></i></a>
    </div>
    <div class="tab-content">
        <div class="tab-empty">

            <div class="card col-md-10 m-2">
                <div class="card-header">
                    <i class="fa fa-cog mr-2"></i> <small><strong><?= inc('app-name') ?></strong></small>
                </div>
                <div class="card-body">
                    <?php
                    if (inc('playstore-status') == 'true') {
                        echo '
                            <div class="row">
                                <div class="col-md-6">
                                    <a href="' . inc('playstore-url') . '" target="_blank">
                                        <center>
                                            <strong>Scan To Play Store</strong>
                                            <div id="play_store"></div>
                                        </center>
                                    </a>
                                </div>
                                <div class="col-md-6">
                                    ' . inc('playstore-desk') . '
                                </div>
                            </div>
                                ';
                    } else {
                        echo '
                            <div class="row">
                                <div class="col-md-6">
                                    <a href="' . XURL . '" target="_blank">
                                        <center>
                                        <strong>Scan To Website</strong>
                                        <div id="qrmain"></div>
                                        </center>
                                    </a>
                                </div>
                                <div class="col-md-6">
                                    ' . inc('desk-app') . '
                                </div>
                            </div>
                            ';
                    }
                    ?>

                </div>
                <div class="card-footer">
                    <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" width="32" class="mr-2"><?= inc('nama-instansi') ?><br>
                </div>
            </div>
        </div>
        <div class="tab-loading">
            <div>
                <span class="display-8">Loading ... <i class="fa fa-sync fa-spin ml-2"></i></span>
            </div>
        </div>
    </div>
</div>


</div>

<!--  End Content-->