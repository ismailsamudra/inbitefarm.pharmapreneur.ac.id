<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />
    <title>AKTIFASI</title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/bootstrap_4.3.1.min.css">
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/themes/metro/easyui.css">
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/themes/icon.css">
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/themes/color.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/fontawesome-5.0.9/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/toastr/toastr.min.css">
    <script src="<?= XROOT ?>script/easyui/jquery.min.js"></script>
    <script src="<?= XROOT ?>script/easyui/jquery.easyui.min.js"></script>
    <script src="<?= XROOT ?>script/easyui/datagrid-filter.js"></script>
    <script src="<?= XROOT ?>script/easyui/datagrid-detailview.js"></script>
    <script src="<?= XROOT ?>script/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= XROOT ?>script/toastr/toastr.min.js"></script>
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/ui-sunny/easyui.css">
    <style>
        body {
            background-color: <?= color('primary-a') ?>;
            color: <?= color('primary-b') ?>;
        }

        .form_login {
            left: 50%;
            top: 50%;
            position: absolute;
            transform: translate(-50%, -50%);
        }

        @media only screen and (max-width: 600px) {
            /* .form_login {
                left: 0;
                top: 50%;
                position: absolute;
                transform: translate(-50%, -50%);
            } */
        }
    </style>
</head>

<body>
    <div class="form_login">
        <center>
            <img src="<?= XROOT ?>img/dev/lock.gif" width="240px" class="img-fluid">
            <br>
            APLIKASI TERKUNCI
            <br>
            <div class="col">
                <br>
                <small><strong>URL : <?= XURL ?></strong></small>
                <br>
                Silahkan Masukkan KODE SERTIFIKAT
                <br>
                <small>BY : <strong>ISMAIL SAMUDRA</strong></small>
                <br>
                <small>No.Whatsapp : <a href="https://wa.me/+6283136245050" target="_blank" style="color: <?= color('primary-b'); ?>;"><strong>083136245050</strong></a></small>
                <br>
            </div>
        </center>
        <div class="card" style="width: 380px;" id="c1">
            <div class="card-header text-dark">
                <small><strong>INPUT KODE SERTIFIKAT</strong></small>
            </div>
            <textarea name="kode" id="kode" cols="30" rows="4" class="form-control"></textarea>
            <div class="card-footer">
                <a href="javascript:void(0);" onclick="aktif();" class="btn-sm btn-dark d-block text-center">AKTIFKAN</a>
            </div>
        </div>
        <div class="card" style="width: 380px;" id="c2">
            <div class="card-header text-dark">
                <small><strong>KODE SERTIFIKAT BERHASIL DI AKTIFKAN</strong></small>
            </div>
            <small class="text-center text-dark">Tanggal Expire : <strong id="tgl"></strong></small>
            <div class="card-footer">
                <a href="/apps" class="btn-sm btn-dark d-block text-center">GO APPS</a>
            </div>
        </div>
    </div>
    <!--START Modal 1-->
    <div class="modal fade" id="load" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <br>
            <br>
            <br>
            <br>
            <center>
                <img src="<?= XROOT ?>img/dev/loading.gif" width="140">
            </center>
        </div>
    </div>
    <!-- End Modal 1-->
    <script type="text/javascript">
        $('#c2').hide();
        $('#c1').show();

        function aktif() {
            $("#load").modal({
                backdrop: "static"
            });
            var kode = document.getElementById('kode').value;
            if (kode == '') {
                $.messager.show({
                    title: 'Error',
                    msg: 'Kode Sertifikat belum di isi.'
                });
            }
            $.post("<?= XROOT ?>apps/aktif", {
                kode
            }, function(result) {
                if (result.success) {
                    $("#load").modal('hide');
                    document.getElementById('tgl').innerHTML = result.data;
                    $('#c1').hide();
                    $('#c2').show();
                    $.messager.show({ // show error message
                        title: 'Success !',
                        msg: 'Berhasil.'
                    });
                } else {
                    $("#load").modal('hide');
                    $.messager.show({ // show error message
                        title: 'Error',
                        msg: result.errorMsg
                    });
                }
                $("#load").modal('hide');
            }, 'json');
        }
        //=============================
        if ('<?= session()->getFlashdata('info'); ?>' == '') {} else {
            $.messager.show({
                title: 'Success',
                msg: '<?= session()->getFlashdata('info'); ?>'
            });
        }
        if ('<?= session()->getFlashdata('error'); ?>' == '') {} else {
            $.messager.show({
                title: 'Error',
                msg: '<?= session()->getFlashdata('error'); ?>'
            });
        }
        //=============================
    </script>
</body>

</html>