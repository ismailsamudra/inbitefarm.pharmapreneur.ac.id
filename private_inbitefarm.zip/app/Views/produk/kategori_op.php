<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a href="" style="color: <?= color('primary-b') ?>;">
                <strong>
                    <i class="fa fa-cubes mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                </strong>
            </a>
            <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="" class="easyui-datagrid" singleSelect="true" style="width: 100%;height:600px;" fitColumns="true" rowNumbers="true" pagination="false" url="<?= XROOT ?>produk/get_kategori" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>

        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Menuju Item.
                <hr>
                Untuk Menu Lain Klick Kanan jika desktop dan sentuh tahan jika HP.
                <hr>
            </div>
            <br>
        </div>
        <center>
            <i class="fa fa-cubes fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- KLICK KANAN START -->
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="go();"><i class="fa fa-cubes mr-2"></i>Item</a>
</div>
<!-- KLICK KANAN END -->
<input type="hidden" id="id">
<script type="text/javascript">
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            status = (row.status == 'true') ? 'YA' : 'TIDAK';
            var t = `
            <div class="card col table-responsive my-1">
                <div class="row">
                    <div class="col-md-2">
                        <small>Nama</small>
                    </div>
                    <div class="col-md-10">
                    <strong> ` + row.nama + `</strong>  
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <small>Tampikan Di Web</small>
                    </div>
                    <div class="col-md-10">
                    <strong> ` + status + `</strong>  
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <small>Setting Class</small>
                    </div>
                    <div class="col-md-10">
                    <strong> A : ` + row.class_a1 + `/` + row.class_a2 + ` , B : ` + row.class_b1 + `/` + row.class_b2 + ` , C : ` + row.class_c1 + `/` + row.class_c2 + `</strong>  
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <small>Keterangan</small>
                    </div>
                    <div class="col-md-10">
                    ` + row.ket + `
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <small>Time Create</small>
                    </div>
                    <div class="col-md-10">
                    <strong> ` + row.at_create + `</strong>  
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <small>Time Update</small>
                    </div>
                    <div class="col-md-10">
                    <strong> ` + row.at_update + `</strong>  
                    </div>
                </div>
            </div>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function go() {
        var id = document.getElementById("id").value;
        window.location.href = '<?= XROOT ?>produk/data/' + id;
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                document.getElementById("id").value = row.id;
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                var row = $('#dguser').datagrid('getSelected');
                if (row) {
                    document.getElementById("id").value = row.id;
                    go();
                }
            },
            rowStyler: function(index, row) {
                if (row.status == 'false') {
                    return 'font-weight:bold;background-color: #e60e11;color:#000;';
                }
            }
        })

    })
    //-----------------------------------------end
</script>