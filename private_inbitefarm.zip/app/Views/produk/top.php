<link rel="stylesheet" href="<?= XROOT ?>script/summernote/summernote-bs4.min.css">
<script src="<?= XROOT ?>script/summernote/summernote-bs4.min.js"></script>
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5><small><i class="fab fa-android mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?></small>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<style>
    .image_upload>input {
        display: none;
    }

    /* input[type=text]{width:220px;height:auto;} */
</style>
<!-- BODY START -->
<div class="container mt-2">

    <div class="col-12">
        <div class="row">
            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                        <small>
                            <strong>
                                <x>
                                    NB : KLICK GAMBAR UNTUK MENGGANTI.
                                    <a href="javascript:void(0);" data-toggle="modal" data-target="#edit" class="btn-sm bt-1 float-right mt-1" title="EDIT"><i class="fa fa-edit"></i></a></h5>
                                </x>
                                <div class="small">&nbsp;&nbsp;Extension : 'png','svg','jpg','jpeg'</div>
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="col">
                                <small>
                                    <strong>
                                        Main Image
                                    </strong>
                                </small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-6">
                        <center>
                            <span class="image_upload">
                                <label for="btn_logo_p">
                                    <a class="btn" rel="nofollow" id="btn_img">
                                        <div id="logo_p">
                                            <img src="<?= XROOT . 'img/instansi/' . inc("web_produk_img") ?>" width="100%">
                                        </div>
                                    </a>
                                </label>
                                <input type="file" name="btn_logo_p" id="btn_logo_p">
                            </span>
                        </center>
                    </div>
                </div>

            </div>
            <div class="col-md-8">

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Label
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("web_produk_label") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Warna Tulisan
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive" style="background-color:<?= inc("web_produk_text_color") ?>">.
                        </div>
                    </div>
                </div>


            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
<!-- BODY END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="_user"><i class="fa fa-edit mr-2"></i>Edit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form action="" method="post" enctype="multipart/form-data">

                    <div class="row">
                        <div class="col-md-12">
                            <small>Label</small>
                            <input type="text" class="form-control" name="web_produk_label" value="<?= inc("web_produk_label") ?>">
                        </div>
                        <div class="col-md-12">
                            <small>Warna Tulisan</small>
                            <input type="color" class="form-control" name="web_produk_text_color" value="<?= inc("web_produk_text_color") ?>" required>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</button>
            </div>

            </form>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<script type="text/javascript">
    $('#desk2').summernote({
        height: 240,
        // themes:paper,
        airMode: false
    })
    //===========================================
    $(document).ready(function() {
        $('#btn_logo_p').on('change', function() {
            var url = '<?= XROOT ?>inc/upload_logo/web_produk_img';
            var property = document.getElementById('btn_logo_p').files[0];
            var image_name = property.name;
            var image_extension = image_name.split('.').pop().toLowerCase();
            var e = image_extension;
            if (e !== 'png' && e !== 'svg' && e !== 'jpg' && e !== 'jpeg') {
                toastr.error('Logo Extensi Harus [ png , svg , jpg , jpeg ].');
                exit;
            }
            var form_data = new FormData();
            form_data.append("file", property);

            $.ajax({
                url: url,
                method: 'POST',
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    toastr.success('gambar Main berhasil di ganti.');
                    $('#logo_p').html(data);
                }
            });
        });
    });
    //===========================================
</script>