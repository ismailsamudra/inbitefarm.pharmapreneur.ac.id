<?php $o = db('produk_kategori')->getWhere(['id' => $id], 1)->getRow(); ?>
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <a href="" style="color: <?= color('primary-b') ?>;">
                <strong>
                    <i class="fa fa-shopping-cart mr-2"></i> ORDER <?= $status ?>
                </strong>
            </a>
            <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="#toolbarCustomer" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="true" pagination="true" url="<?= XROOT ?>produk/get_order/<?= $status ?>" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="id" align="center" sortable="true">ID Order</th>
                                <th field="nama" align="center" sortable="true">Nama</th>
                                <th field="hp" align="center" sortable="true">Hp/Wa</th>
                                <th field="email" align="center" sortable="true">Email</th>
                                <th field="alamat" align="center" sortable="true">Alamat</th>
                                <th field="kategori" align="center" sortable="true">Kategori</th>
                                <th field="kode_pack" align="center" sortable="true">Kode Pack</th>
                                <th field="produk_qty" align="center" sortable="true">Qty</th>
                                <th field="idr" formatter="ammount" align="center" sortable="true">Ammount</th>
                                <th field="tgl_order" formatter="tgl_order" align="center" sortable="true">Tgl Order</th>
                                <th field="admin" align="center" sortable="true">Last Admin</th>
                                <th field="time_update" formatter="time_update" align="center" sortable="true">Time Update</th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>

        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Konfirmasi Data.
                <hr>
                Untuk Menu Lain Klick Kanan jika desktop dan sentuh tahan jika HP.
                <hr>
            </div>
            <br>
        </div>
        <center>
            <i class="fa fa-shopping-cart fa-5x"></i><br>
            <strong>
                ORDER <?= $status ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<div id="toolbarCustomer">
    <div class="row">
        <div class="col-md-6">
            <!---------SEARCH BOX START--------->
            <input id="searchCustomer" class="easyui-searchbox" data-options="prompt:'Cari..',searcher:doSearchCustomer,
            inputEvents: $.extend({}, $.fn.searchbox.defaults.inputEvents, {
                keyup: function(e){
                    var t = $(e.data.target);
                    var opts = t.searchbox('options');
                    t.searchbox('setValue', $(this).val());
                    opts.searcher.call(t[0],t.searchbox('getValue'),t.searchbox('getName'));
                }
            })
        " style="width:100%;"></input>
            <!---------SEARCH BOX END----------->
        </div>
    </div>
</div>
<!-- KLICK KANAN START -->
<?php
$konfirm = '';
if ($status == 'Baru') {
    $konfirmasi = '<a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="proses();"><i class="fa fa-cog mr-2"></i>Proses</a>';
}
if ($status == 'Proses') {
    $konfirmasi = '<a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="proses();"><i class="fa fa-flag mr-2"></i>Lunaskan</a>';
}
$batal = '';
if (me() == '1' || me() == '28071986') {
    if ($status != 'Batal') {
        $batal = '<a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="batal();"><i class="fa fa-trash mr-2 text-danger"></i> Batal</a>';
    } else {
        $batal = '';
    }
}
?>
<div id="mm" class="easyui-menu">
    <?= $konfirmasi ?>
    <?= $batal ?>
</div>
<!-- KLICK KANAN END -->

<script type="text/javascript">
    //-----------------------------------------start
    function ammount(val, row) {
        for (var name in row) {
            return 'Rp. ' + formatidr(row.idr);
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function tgl_order(val, row) {
        for (var name in row) {
            return (row.tgl_order != "") ? moment(row.tgl_order).format('DD/MM/YYYY') : '--';
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function time_update(val, row) {
        for (var name in row) {
            return (row.time_update != "") ? moment(row.time_update).format('DD/MM/YYYY') : '--';
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function lb_harga(val) {
        var res = formatidr(val);
        document.getElementById("lb_harga").innerHTML = res;
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function formatidr(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        // tambahkan titik jika yang di input sudah menjadi angka ribuan
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'IDR. ' + rupiah : '');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function doSearchCustomer() {
        $('#dguser').datagrid('load', {
            search_customer: $('#searchCustomer').val()
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function proses() {
        var status = '<?= $status ?>';
        if (status == 'Baru') {
            atention = 'Proses';
        } else if (status == 'Proses') {
            atention = 'Lunaskan';
        }
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin ' + atention + ' data ini ?<br>ID Order : ' + row.id + '<br><br><center><i class="fa fa-flag fa-2x text-primary mr-2"></i> Konfirmasi</center>', function(r) {
                if (r) {
                    $.post("<?= XROOT ?>produk/proses_order/<?= $status ?>", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Berhasil Di ' + atention);
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function batal() {
        var status = '<?= $status ?>';
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Membatalkan data ini ?<br>ID Order : ' + row.id + '<br><br><center><i class="fa fa-trash fa-2x text-danger mr-2"></i> PemBatalan</center>', function(r) {
                if (r) {
                    $.post("<?= XROOT ?>produk/batal_order/<?= $status ?>", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Berhasil Di Batalkan');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                proses();
            }
        })

    })
    //-----------------------------------------end
    $('#harga').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
</script>