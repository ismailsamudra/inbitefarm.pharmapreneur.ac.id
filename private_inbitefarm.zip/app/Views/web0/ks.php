<!-- BODY START ----------------------------------------------------------->
<div class="col-md-12 my-4">
    <div class="full center">
        <div class="heading_main text_align_center">
            <h2><span class="theme_color">KERJA</span> SAMA</h2>
            <p class="large"><?= inc('app-name') ?></p>
        </div>
    </div>
</div>
<style>
    /* .br {
        border-radius: 10px;
        border: 1px solid <?= color('primary-c') ?>;
        color: <?= color('primary-c') ?>;
    } */
    .round {
        border-radius: 10px;
    }

    .bot {
        position: absolute;
        bottom: 0;
        left: 0;
    }
</style>
<div class="section layout_padding">
    <div class="container">
        <?php $berita = db('web_kerja_sama')->orderBy('id', 'DESC')->getWhere(['status' => 'true'])->getResult(); ?>
        <?= (!$berita) ? '<center><strong><br><br><br><br>NO CONTENT<br><br><br><br></strong></center>' : ''; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <?php foreach ($berita as $o) : ?>
                        <?php (empty($o->img)) ? $img = 'default2.jpg' : $img = $o->img; ?>
                        <div class="col-md-6 my-2">

                            <div class="row g-0">
                                <div class="col-6 br">
                                    <img class="img-responsive my-2 round" src="<?= XROOT ?>img/web/berita/<?= $img ?>" alt="#" />
                                </div>
                                <div class="col-6">
                                    <strong>
                                        <?= $o->judul ?>
                                        <a href="<?= XROOT ?>web/ks/<?= en64($o->id) ?>" class="bot m-2" title="Selengkapnya"><u>Selengkapnya</u><i class="fa fa-sign-out-alt ml-2"></i></a>
                                    </strong>
                                    <br>
                                    <small>Tgl Berlaku : <?= date("d-m-Y", strtotime($o->tgl_berlaku)) ?></small> <br>
                                    <small>Tgl Akhir : <?= date("d-m-Y", strtotime($o->tgl_akhir)) ?></small> <br>
                                    <small>Time Post : <?= $o->time ?></small><br>
                                    <small>View : <?= $o->view ?></small>
                                </div>
                            </div>

                        </div>
                    <?php endforeach ?>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- BODY END ------------------------------------------------------------->