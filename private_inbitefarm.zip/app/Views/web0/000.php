<!-- BODY START ----------------------------------------------------------->
<div class="col-md-12 my-4">
    <div class="full center">
        <div class="heading_main text_align_center">
            <h2><span class="theme_color">MODUL</span> 001</h2>
            <p class="large"><?= inc('app-name') ?></p>
        </div>
    </div>
</div>
<style>
    .br {
        border-radius: 10px;
        border: 1px solid <?= color('primary-c') ?>;
        color: <?= color('primary-c') ?>;
    }

    .bot {
        position: absolute;
        bottom: 0;
        left: 0;
    }
</style>
<div class="section layout_padding">
    <div class="container">

        <center><strong><br><br><br><br>NO CONTENT<br><br><br><br></strong></center>

    </div>
</div>
</div>

<!-- BODY END ------------------------------------------------------------->