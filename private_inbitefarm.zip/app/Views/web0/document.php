<script src="<?= XROOT ?>script/web/js/jquery.min.js"></script>
<!-- BODY START ----------------------------------------------------------->
<div class="col-md-12 my-4">
    <div class="full center">
        <div class="heading_main text_align_center">
            <h2><span class="theme_color">DOCU</span>MENT</h2>
            <p class="large" id="label_top"><?= inc('app-name') ?></p>
        </div>
    </div>
</div>

<!-- <div class="section layout_padding"> -->
<div class="container">

    <!-- ACCORDION START -->
    <div id="accordion">
        <!-- ======================================START LINE====================================== -->
        <a class="-link" data-toggle="collapse" href="#description1" onclick="clik('c-1')">
            <i id="c-1" class="fa fa-folder fa-2x mr-2 text-warning"></i>GeeksforGeeks
        </a>
        <script>
            $('#c-1').val('0');
        </script>
        <div id="description1" class="collapse" data-parent="#accordion">
            <!-- ACCORDION START -->
            <div id="accordion2">
                <!-- ======================================START LINE====================================== -->
                <a class="-link" data-toggle="collapse" href="#description2" onclick="clik('c-2')">
                    <i id="c-2" class="fa fa-folder fa-2x ml-4 mr-2 text-warning"></i>GeeksforGeeks
                </a>
                <script>
                    $('#c-2').val('0');
                </script>
                <div id="description2" class="collapse" data-parent="#accordion2">
                    <!-- <i class="fa fa-folder fa-2x mr-2 text-warning"></i>GeeksforGeeks is a computer science portal. -->
                    <div class="col-12 ml-4" id="c-">
                        <a href="javascript:void(0);" onclick="show_pdf('c-');">
                            <div class="card col m-1">
                                <div class="row">
                                    <div class="col-md-1">
                                        <i class="fa fa-file-pdf fa-2x text-danger m-1 mr-2"></i>
                                    </div>
                                    <div class="col-md-4">
                                        <strong class="mt-2">GeeksforGeeks</strong>
                                    </div>
                                    <div class="col-md-4">
                                        <small>Time Update : 00/00/0000</small>
                                    </div>
                                    <div class="col-md-3">
                                        <strong><small>Total Unduh : 0</small></strong>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- <i class="fa fa-folder fa-2x mr-2 text-warning"></i>GeeksforGeeks is a computer science portal. -->
                </div>
                <!-- =======================================END LINE======================================= -->
            </div>
            <!-- ACCORDION END -->
        </div>
        <!-- =======================================END LINE======================================= -->
    </div>
    <!-- ACCORDION END -->
    <!-- ACCORDION START -->
    <div id="accordion3">
        <!-- ======================================START LINE====================================== -->
        <a class="-link" data-toggle="collapse" href="#description3" onclick="clik('c-3')">
            <i id="c-3" class="fa fa-folder fa-2x mr-2 text-warning"></i>GeeksforGeeks
        </a>
        <script>
            $('#c-3').val('0');
        </script>
        <div id="description3" class="collapse" data-parent="#accordion3">
            <!-- ACCORDION START -->
            <div id="accordion4">
                <!-- ======================================START LINE====================================== -->
                <a class="-link" data-toggle="collapse" href="#description4" onclick="clik('c-4')">
                    <i id="c-4" class="fa fa-folder ml-4 fa-2x mr-2 text-warning"></i>GeeksforGeeks
                </a>
                <script>
                    $('#c-4').val('0');
                </script>
                <div id="description4" class="collapse" data-parent="#accordion4">
                    <!-- <i class="fa fa-folder fa-2x mr-2 text-warning"></i>GeeksforGeeks is a computer science portal. -->
                    <div class="col-12 ml-4" id="c-">
                        <a href="javascript:void(0);" onclick="show_pdf('c-');">
                            <div class="card col m-1">
                                <div class="row">
                                    <div class="col-md-1">
                                        <i class="fa fa-file-pdf fa-2x text-danger m-1 mr-2"></i>
                                    </div>
                                    <div class="col-md-4">
                                        <strong class="mt-2">GeeksforGeeks</strong>
                                    </div>
                                    <div class="col-md-4">
                                        <small>Time Update : 00/00/0000</small>
                                    </div>
                                    <div class="col-md-3">
                                        <strong><small>Total Unduh : 0</small></strong>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- <i class="fa fa-folder fa-2x mr-2 text-warning"></i>GeeksforGeeks is a computer science portal. -->
                </div>
                <!-- =======================================END LINE======================================= -->
            </div>
            <!-- ACCORDION END -->
            <!-- ACCORDION START -->
            <div id="accordion5">
                <!-- ======================================START LINE====================================== -->
                <a class="-link" data-toggle="collapse" href="#description5" onclick="clik('c-5')">
                    <i id="c-5" class="fa fa-folder fa-2x ml-4 mr-2 text-warning"></i>GeeksforGeeks
                </a>
                <script>
                    $('#c-5').val('0');
                </script>
                <div id="description5" class="collapse" data-parent="#accordion5">
                    <!-- <i class="fa fa-folder fa-2x mr-2 text-warning"></i>GeeksforGeeks is a computer science portal. -->
                    <div class="col-12 ml-4" id="c-">
                        <a href="javascript:void(0);" onclick="show_pdf('c-');">
                            <div class="card col m-1">
                                <div class="row">
                                    <div class="col-md-1">
                                        <i class="fa fa-file-pdf fa-2x text-danger m-1 mr-2"></i>
                                    </div>
                                    <div class="col-md-4">
                                        <strong class="mt-2">GeeksforGeeks</strong>
                                    </div>
                                    <div class="col-md-4">
                                        <small>Time Update : 00/00/0000</small>
                                    </div>
                                    <div class="col-md-3">
                                        <strong><small>Total Unduh : 0</small></strong>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- <i class="fa fa-folder fa-2x mr-2 text-warning"></i>GeeksforGeeks is a computer science portal. -->
                </div>
                <!-- =======================================END LINE======================================= -->
            </div>
            <!-- ACCORDION END -->
        </div>
        <!-- =======================================END LINE======================================= -->
    </div>
    <!-- ACCORDION END -->

</div>
<!-- </div> -->
<script>
    function clik(id) {
        if ($('#' + id).val() == '0') {
            $('#' + id).val('1');
            $('#' + id).removeClass("fa fa-folder");
            $('#' + id).addClass("fa fa-folder-open");
        } else {
            $('#' + id).val('0');
            $('#' + id).removeClass("fa fa-folder-open");
            $('#' + id).addClass("fa fa-folder");
        }
    }
</script>
<!-- BODY END ------------------------------------------------------------->
<br><br><br><br><br><br><br><br>