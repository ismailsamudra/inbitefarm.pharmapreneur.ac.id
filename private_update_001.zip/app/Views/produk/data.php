<?php $o = db('produk_kategori')->getWhere(['id' => $id], 1)->getRow(); ?>
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <a href="javascript:void(0);" onclick="history.back()" class="btn-sm bt-1 float-left mr-2" title="Back"><i class="fa fa-arrow-left"></i></a>
            <a href="javascript:void(0);" onclick="add()" class="btn-sm bt-1 float-left" title="ADD"><i class="fa fa-plus"></i></a>
            <a href="" style="color: <?= color('primary-b') ?>;">
                <strong>
                    <i class="fa fa-cubes mr-2"></i> <?= strtoupper($o->nama) ?>
                </strong>
            </a>
            <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="#toolbarCustomer" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="true" pagination="true" url="<?= XROOT ?>produk/get_data/<?= $id ?>" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>

        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Edit.
                <hr>
                Untuk Menu Lain Klick Kanan jika desktop dan sentuh tahan jika HP.
                <hr>
                Di rekomedasikan gambar berlatar putih atau transparan dengan ukuran yg sama dengan yg lain guna menyesuaikan dengan tampilan di website.
                <hr>
            </div>
            <br>
        </div>
        <center>
            <i class="fa fa-cubes fa-5x"></i><br>
            <strong>
                ITEM <br>
                <?= strtoupper($o->nama) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<div id="toolbarCustomer">
    <div class="row">
        <div class="col-md-6">
            <!---------SEARCH BOX START--------->
            <input id="searchCustomer" class="easyui-searchbox" data-options="prompt:'Cari..',searcher:doSearchCustomer,
            inputEvents: $.extend({}, $.fn.searchbox.defaults.inputEvents, {
                keyup: function(e){
                    var t = $(e.data.target);
                    var opts = t.searchbox('options');
                    t.searchbox('setValue', $(this).val());
                    opts.searcher.call(t[0],t.searchbox('getValue'),t.searchbox('getName'));
                }
            })
        " style="width:100%;"></input>
            <!---------SEARCH BOX END----------->
        </div>
    </div>
</div>
<!-- KLICK KANAN START -->
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="edit();"><i class="fa fa-edit mr-2"></i>Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="change_status();"><span id="btn-status"></span></a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser();"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a>
</div>
<!-- KLICK KANAN END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="fm" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="id">
                    <div class="row">
                        <div class="col-md-6">
                            <label for=""><small>Kode Batch [ Wajib ]</small></label>
                            <input type="text" name="nama" id="nama" class="form-control">

                            <div class="row my-2">
                                <div class="col-md-3">
                                    <label for=""><small>Class</small></label>
                                </div>
                                <div class="col-md-3">
                                    <input type="radio" name="class" id="class1" value="A"> A
                                </div>
                                <div class="col-md-3">
                                    <input type="radio" name="class" id="class2" value="B"> B
                                </div>
                                <div class="col-md-3">
                                    <input type="radio" name="class" id="class3" value="C"> C
                                </div>
                            </div>

                            <label for=""><small>Harga [ IDR. <span id="lb_harga"></span> ] /Satuan [ Wajib ]</small></label>
                            <input type="text" name="harga" id="harga" onkeyup="lb_harga(this.value);" class="form-control">
                            <label for=""><small>Tanggal Ready [ Wajib ]</small></label>
                            <input type="date" name="tgl_ready" id="tgl_ready" class="form-control">

                            <div class="row my-2">
                                <div class="col-md-6">
                                    <label for=""><small>jumblah Lubang [ Wajib ]</small></label>
                                    <input type="number" name="lubang" id="lubang" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label for=""><small>Min Order /satuan [ Wajib ]</small></label>
                                    <input type="number" name="min_order" id="min_order" class="form-control">
                                </div>
                            </div>
                            <small id="lb_id">UPLOAD GAMBAR [ Wajib ]</small>
                            <input type="file" name="file" id="file" accept="image/*" class="form-control">
                        </div>
                        <div class="col-md-6">

                            <div class="row my-2">
                                <div class="col-md-4">
                                    <label for=""><small>Produk Baru</small></label>
                                </div>
                                <div class="col-md-4">
                                    <input type="radio" name="new" id="new1" value="Y"> YA
                                </div>
                                <div class="col-md-4">
                                    <input type="radio" name="new" id="new2" value="T"> BUKAN
                                </div>
                            </div>

                            <div class="row my-2">
                                <div class="col-md-4">
                                    <label for=""><small>Produk Unggul</small></label>
                                </div>
                                <div class="col-md-4">
                                    <input type="radio" name="unggul" id="unggul1" value="Y"> YA
                                </div>
                                <div class="col-md-4">
                                    <input type="radio" name="unggul" id="unggul2" value="T"> BUKAN
                                </div>
                            </div>
                            <label for=""><small>Deskripsi [ Optional ]</small></label>
                            <textarea name="desk" id="desk" cols="30" rows="5" class="form-control"></textarea>
                        </div>
                    </div>

                </form>

            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>
            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<script type="text/javascript">
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            status = (row.status == 'true') ? 'YA' : 'TIDAK';
            baru = (row.new == 'Y') ? 'YA' : 'BUKAN';
            unggul = (row.unggul == 'Y') ? 'YA' : 'BUKAN';
            stok = (row.habis == 'Y') ? 'HABIS' : 'ADA';
            var t = `
            <div class="card col table-responsive my-1">
                <div class="row">
                    <div class="col-md-2">
                    <img src="<?= XROOT ?>img/web/produk/` + row.img + `" width="100%">
                    </div>
                    <div class="col-md-10">
                        <div class="row">
                            <div class="col-md-2">
                                <small>Kode Batch</small>
                            </div>
                            <div class="col-md-10">
                            <strong> ` + row.nama + ` <small>Class :</small> ` + row.class + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Status</small>
                            </div>
                            <div class="col-md-10">
                            <strong> ` + row.aksi + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Tanggal Ready</small>
                            </div>
                            <div class="col-md-10">
                            <strong> ` + moment(row.tgl_ready).format('DD/MM/YYYY') + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Lubang</small>
                            </div>
                            <div class="col-md-10">
                            <strong> ` + row.lubang + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Minimal Order</small>
                            </div>
                            <div class="col-md-10">
                            <strong> ` + row.min_order + ` ` + row.satuan + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Stok Awal</small>
                            </div>
                            <div class="col-md-10">
                            <strong> ` + row.qty_awal + ` ` + row.satuan + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Stok Sisa</small>
                            </div>
                            <div class="col-md-10">
                            <h5> ` + row.qty + ` ` + row.satuan + `</h5>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Harga</small>
                            </div>
                            <div class="col-md-10">
                           IDR . ` + formatidr(row.harga) + ` /` + row.satuan + `
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Produk Baru</small>
                            </div>
                            <div class="col-md-10">
                            <strong> ` + baru + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Produk Unggulan</small>
                            </div>
                            <div class="col-md-10">
                            <strong> ` + unggul + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Tampikan Di Web</small>
                            </div>
                            <div class="col-md-10">
                            <strong> ` + status + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>URL</small>
                            </div>
                            <div class="col-md-10">
                            <a href="<?= XURL ?>web/index/` + row.id + `" target="_blank"><?= XURL ?>web/index/` + row.id + `</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Time Create</small>
                            </div>
                            <div class="col-md-10">
                            ` + row.at_create + `  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <small>Time Update</small>
                            </div>
                            <div class="col-md-10">
                            ` + row.at_update + `  
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function lb_harga(val) {
        var res = formatidr(val);
        document.getElementById("lb_harga").innerHTML = res;
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function formatidr(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        // tambahkan titik jika yang di input sudah menjadi angka ribuan
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'IDR. ' + rupiah : '');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function doSearchCustomer() {
        $('#dguser').datagrid('load', {
            search_customer: $('#searchCustomer').val()
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        $('#lb_id').html('UPLOAD GAMBAR [ Wajib ]');
        document.getElementById("file").value = '';
        document.getElementById("new1").checked = true;
        document.getElementById("unggul2").checked = true;
        document.getElementById("class1").checked = true;
        document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Tambah Data</h5>';
        document.getElementById("id").value = 'insert';
        $('#edit').modal('show');

    }
    //-----------------------------------------end
    //-----------------------------------------start
    function edit() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            $('#lb_id').html('GANTI GAMBAR [ Optional ]');
            document.getElementById("lb_harga").innerHTML = formatidr(row.harga);
            document.getElementById("file").value = '';
            document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Data</h5>';
            $('#edit').modal('show');
        } else {
            msg('Error', 'Klick Sekali Lagi');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function change_status() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Merubah Status data ini ?<br>Nama  Item : ' + row.nama, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>produk/status_data", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Status Berhasil Di Ubah');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>Nama  Item : ' + row.nama, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>produk/del_data", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Berhasil Di Hapus');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        var nama = document.getElementById("nama").value;
        if (nama == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Nama Item Belum Di isi.'
            });
            $('#nama').focus();
            exit;
        }
        var harga = document.getElementById("harga").value;
        if (harga == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'harga Item Belum Di isi.'
            });
            $('#harga').focus();
            exit;
        }
        var tgl_ready = document.getElementById("tgl_ready").value;
        if (tgl_ready == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'tgl_ready Item Belum Di isi.'
            });
            $('#tgl_ready').focus();
            exit;
        }
        var lubang = document.getElementById("lubang").value;
        if (lubang == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'lubang Item Belum Di isi.'
            });
            $('#lubang').focus();
            exit;
        }
        var min_order = document.getElementById("min_order").value;
        if (min_order == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'min_order Item Belum Di isi.'
            });
            $('#min_order').focus();
            exit;
        }
        $('#fm').form('submit', {
            url: '<?= XROOT ?>produk/save_data/<?= $id ?>',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.success) {
                    $('#edit').modal('hide');
                    $('#dguser').datagrid('reload');
                    msg('Success !', 'Berhasil di Save');
                } else {
                    msg('Error', result.errorMsg);
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                if (row.status == 'true') {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-danger mr-2"></i>Hide in Web';
                } else {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-success mr-2"></i>Show in Web';
                }
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                edit();
            },
            rowStyler: function(index, row) {
                if (row.status == 'false') {
                    return 'font-weight:bold;background-color: #e60e11;color:#000;';
                }
            }
        })

    })
    //-----------------------------------------end
    $('#harga').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
</script>