<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?= $title ?></title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link href="<?= XROOT ?>script/web2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/price-range.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/animate.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/main.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/responsive.css" rel="stylesheet">
    <?php
    echo view('part/web/css');

    ?>
</head>
<!--/head-->

<body>
    <!-- BODY START -->
    <div class="features_items">
        <!--features_items-->

        <?php foreach ($item as $x) : ?>
            <div class="col-sm-3">
                <div class="product-image-wrapper">
                    <div class="single-products">
                        <div class="productinfo text-center">
                            <?php
                            if ($x->aksi == 'Semai') {
                                $warna = '#0066FF';
                            } elseif ($x->aksi == 'Ready') {
                                $warna = '#38761d';
                            } else {
                                $warna = '#f44336';
                            }
                            if ($x->aksi != 'null') {
                                echo '<div class="ribbon ribbon-top-right">
                                <span style="background-color:' . $warna . ';">' . $x->aksi . '</span>
                                </div>';
                            }
                            ?>
                            <img src="<?= XROOT ?>img/web/produk/<?= $x->img ?>" alt="" width="100" />
                            <?php
                            if ($x->new == 'Y' && $x->habis == 'T') {
                                echo '<div class="badge"><strong>NEW</strong></div>';
                            }
                            ?>

                            <h2><?= "IDR " . number_format($x->harga, 0, ',', '.') ?></h2>
                            <h5>Kode Batch : <?= $x->nama ?></h5>
                            <h5><strong>Ready : <?= date("d/m/Y", strtotime($x->tgl_ready)) ?> </strong></h5>
                            <a href="<?= XROOT ?>web/selengkapnya/<?= $x->id ?>" class="btn btn-default add-to-cart"><i class="fa fa-arrow-right"></i>Selengkapnya</a>
                        </div>

                    </div>

                </div>
            </div>
        <?php endforeach ?>

    </div>
    <!--features_items-->

    <!-- BODY END -->
</body>
<script src="<?= XROOT ?>script/web2/js/jquery.js"></script>
<script src="<?= XROOT ?>script/web2/js/bootstrap.min.js"></script>
<script src="<?= XROOT ?>script/web2/js/jquery.scrollUp.min.js"></script>
<script src="<?= XROOT ?>script/web2/js/price-range.js"></script>
<script src="<?= XROOT ?>script/web2/js/jquery.prettyPhoto.js"></script>
<!-- <script src="<?= XROOT ?>script/web2/js/main.js"></script> -->
</body>

</html>
<!-- Modal -->
<div id="selengkapnya" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Modal Header</h4>
            </div>
            <div class="modal-body">
                <p>Some text in the modal.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>